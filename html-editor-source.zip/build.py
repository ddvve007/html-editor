#!/usr/bin/env python3
"""Build two standalone HTML editors from shared source and English translations."""
import json,pathlib,re
from datetime import datetime
ROOT=pathlib.Path(__file__).resolve().parent
FILES=['icons.js','editor.core.js','persist.js','editor.ui.js','ckpt.js','source.js','shell.js']
TRANSLATIONS=json.loads((ROOT/'translations-en.json').read_text())
def english(text):
    # Replace in one pass: translated output must never be translated a second time.
    pattern='|'.join(re.escape(k) for k in sorted(TRANSLATIONS,key=len,reverse=True))
    return re.sub(pattern,lambda m:TRANSLATIONS[m.group()],text).replace('（','(').replace('）',')')
def build(lang):
    page=(ROOT/'src/page.html').read_text()
    scripts=[(ROOT/'src'/f).read_text() for f in FILES]
    if lang=='en':
        start=page.index('      <div class="hbody">')
        end=page.index('\n      </div>',start)
        page=page[:start]+'      <div class="hbody">'+(ROOT/'help-en.html').read_text()+page[end:]
        page=english(page).replace('lang="zh-CN"','lang="en"')
        scripts=[english(s) if f!='persist.js' else s for f,s in zip(FILES,scripts)]
        scripts=[s.replace("'第'+lines+'行，已选中匹配Text。'","'Line '+lines+': match selected.'") for s in scripts]
        scripts=[s.replace("return (d.getMonth() + 1) + '月' + d.getDate() + '日 ' + hm;", "return d.toLocaleDateString('en-US', {month:'short',day:'numeric'}) + ' ' + hm;") for s in scripts]
        scripts=[s.replace("'《' + (name || 'Untitled') + '》在 '","'“' + (name || 'Untitled') + '” — '") for s in scripts]
    js='\n'.join(scripts)
    assert '</script' not in js
    out=page.replace('/*__EDITOR_JS__*/',js).replace('__BUILD__',datetime.now().strftime('%Y-%m-%d %H:%M'))
    file=ROOT/('html-editor-en.html' if lang=='en' else 'html-editor.html')
    file.write_text(out)
    return file
if __name__=='__main__':
    for lang in ['zh','en']: print(build(lang))
