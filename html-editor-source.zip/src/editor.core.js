/* ============================================================
 * HTML 编辑器 — 核心引擎
 * 父层：文件载入（本地文件 / 链接）
 * 引擎：注入 iframe 的操作层（选中 / 拖动 / 缩放 / 多选 / 文本编辑 / 撤销）
 * ============================================================ */
(function () {
'use strict';

var DE = window.DE = window.DE || {};

/* ==================== 父层 ==================== */
DE.mode = 'edit';
var S = DE.S = { name: '', text: '', url: '' };
var ifr = null, doc = null, win = null;
var $id = function (id) { return document.getElementById(id); };
var toastTimer = null;

function toast(msg, ms) {
  var el = $id('toast');
  el.textContent = msg;
  el.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(function () { el.classList.remove('show'); }, ms || 2600);
}
DE.toast = toast;

/* ---- 引擎状态 ---- */
var sel = DE.sel = [];            // 选中的元素数组
var T = DE.T = new Map();         // HTML 元素 -> {tx, ty, s, orig}
var TS = DE.TS = new Map();       // SVG 元素 -> {tx, ty, s, orig}
var stack = DE.stack = [];        // 撤销栈（逐元素快照，不重建 DOM）
var editing = null;               // 正在文本编辑的元素
var drag = null;                  // 进行中的拖动/缩放
var hoverEl = null;
var pending = null;               // pointerdown 后待判定（点击 or 拖动）
var lastActionT = 0;
var deckEl = null;
var boxLayer = null;
var lastClickEl = null;
var domGen = 0;                   /* 内容容器“重画”代号：重画后旧快照失效 */

DE.getDoc = function () { return doc; };
DE.getWin = function () { return win; };
DE.getDeckEl = function () { return deckEl; };
DE.getK = function () {
  if (!deckEl) return 1;
  var ow = deckEl.offsetWidth || 1600;
  /* 屏幕像素 / 布局像素 的真实比例（deck 布局宽可能 ≠ 1600 设计宽） */
  return (deckEl.getBoundingClientRect().width / ow) || 1;
};
DE.bumpGen = function () { domGen++; T.clear(); TS.clear(); };
/* 编辑动作收尾：通知保持层更新视图内容 */
function pdDirty() {
  if (DE.Shell && DE.Shell.edited) DE.Shell.edited();
  if (DE.Persist && DE.Persist.markDirty) { try { DE.Persist.markDirty(); } catch (e) {} }
}
/* 元素「父级内容空间」的屏幕缩放（stage 缩放型 deck 的拖动/微调换算） */
function Kof(el) {
  var n = el && el.parentElement;
  while (n && n.nodeType === 1) {
    var w = n.offsetWidth, r = 0;
    if (w) { try { r = n.getBoundingClientRect().width; } catch (e) { r = 0; } }
    if (w && r) return (r / w) || 1;
    n = n.parentElement;
  }
  return 1;
}

function resetState() {
  sel.length = 0;
  T.clear(); TS.clear();
  stack.length = 0;
  editing = null; drag = null; hoverEl = null; pending = null;
  lastClickEl = null;
}

/* ---- 载入 ---- */
function load(text, name, url) {
  DE.mode = 'edit';
  S.text = text; S.name = name || 'deck.html'; S.url = url || '';
  $id('fname').textContent = S.name;
  $id('fname').title = S.name;
  if (DE.Shell && DE.Shell.loaded) DE.Shell.loaded();
  $id('fname').classList.remove('empty');
  $id('btnReload').disabled = false;
  $id('btnSaveTop').disabled = false;
  if ($id('btnSource')) $id('btnSource').disabled = false;
  $id('welcome').hidden = true;
  ifr.hidden = false;
  resetState();
  ifr.onload = function () {
    try { initEngine(); }
    catch (err) { toast('初始化编辑引擎失败：' + err.message, 5000); console.error(err); }
    guardDropInFrame();
  };
  ifr.srcdoc = text;
}
DE.load = load;

function openFile(file) {
  var r = new FileReader();
  r.onload = function () {
    var t = String(r.result);
    if (DE.Ckpt && DE.Ckpt.intercept) DE.Ckpt.intercept(file.name, '', t, '已载入 ' + file.name);
    else { load(t, file.name, ''); toast('已载入 ' + file.name); }
  };
  r.onerror = function () { toast('读取文件失败'); };
  r.readAsText(file, 'utf-8');
}

function loadFromUrl(url) {
  toast('正在载入…');
  fetch(url).then(function (r) {
    if (!r.ok) throw new Error('HTTP ' + r.status);
    return r.text();
  }).then(function (t) {
    var nm = decodeURIComponent((url.split('/').pop() || 'deck.html').split('?')[0]);
    if (DE.Ckpt && DE.Ckpt.intercept) DE.Ckpt.intercept(nm, url, t, '已载入（可保存回原文件）');
    else { load(t, nm, url); toast('已载入（可保存回原文件）'); }
  }).catch(function (e) {
    toast('打开失败：' + e.message + '（外部网址需服务端允许跨域）', 5200);
  });
}
DE.loadFromUrl = loadFromUrl;

/* iframe 内拖放守卫：事件落在 deck 上时父层收不到，在这里阻止默认导航并转交 openFile */
function guardDropInFrame() {
  var d;
  try { d = ifr.contentDocument; } catch (e) { return; }
  if (!d || d.__deDropGuard) return;
  d.__deDropGuard = true;
  ['dragenter', 'dragover'].forEach(function (n) {
    d.addEventListener(n, function (e) { e.preventDefault(); }, true);
  });
  d.addEventListener('drop', function (e) {
    e.preventDefault();
    var f = e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files[0];
    if (f) openFile(f);
  }, true);
}

/* ==================== 引擎：工具函数 ==================== */
function isSvg(el) {
  return el && el.namespaceURI === 'http://www.w3.org/2000/svg';
}
function isUiEl(el) {
  var n = el;
  while (n && n.nodeType === 1) {
    if (n.hasAttribute && n.hasAttribute('data-de-ui')) return true;
    n = n.parentElement;
  }
  return false;
}
/* 命中元素（null=空白；undefined=放行不算） */
function hitEl(e) {
  var t = e.target;
  if (!t || t.nodeType !== 1) return null;
  if (t === doc.body || t === doc.documentElement) return null;
  if (t.id === 'deck' || t.id === 'stage') return null;
  if (t.classList && t.classList.contains('slide')) return null;
  /* 线内元素一律解析为整条线容器（端点 .de-ep 在更早的分支已截走）：
     保证选中/拖动作用于 .de-line，线、箭头、两端圆点整体同步 */
  if (t.closest) {
    var ln = t.closest('.de-line');
    if (ln) return ln;
  }
  return t;
}
/* 选父级（到 slide 为止） */
function parentOf(el) {
  var p = el.parentElement;
  if (!p || p === doc.body || el.classList.contains('slide')) return el;
  if (p.classList && p.classList.contains('slide')) return p;
  return p;
}
function clamp(v, a, b) { return v < a ? a : v > b ? b : v; }
function getRect(el) { return el.getBoundingClientRect(); }

/* ==================== 引擎：选中与选框 ==================== */
function select(el) {
  sel.length = 0;
  if (el) sel.push(el);
  lastClickEl = el;
  refreshSel();
}
DE.select = select;

function clearSel() {
  if (!sel.length && !editing) return;
  endEdit();
  sel.length = 0;
  refreshSel();
}
DE.clearSel = clearSel;

/* 移除 hover 高亮：类名清空后连 class 空属性一并移除（否则序列化会多出 class=""，污染快照基线） */
function unhover(el) {
  if (!el || !el.classList) return;
  el.classList.remove('de-hover');
  if (el.getAttribute && !el.getAttribute('class')) el.removeAttribute('class');
}
/* 清除当前 hover 高亮（保持层抓快照前调用，避免把 de-hover 残留记进基线） */
function clearHover() {
  if (hoverEl) { unhover(hoverEl); hoverEl = null; }
}
DE.clearHover = clearHover;

function toggleSel(el) {
  var i = sel.indexOf(el);
  if (i >= 0) sel.splice(i, 1); else sel.push(el);
  lastClickEl = el;
  refreshSel();
}

/* 绘制选框（fixed 覆盖层，屏幕坐标） */
function refreshSel() {
  if (!boxLayer) return;
  boxLayer.innerHTML = '';
  var i, r;
  if (!sel.length) { callUi('onSelChange'); return; }

  if (sel.length === 1) {
    r = getRect(sel[0]);
    drawBox(r, false, false);
    if (canResize(sel[0])) drawHandles(r);
    if (isLineEl(sel[0])) drawLinepts(sel[0]);
  } else {
    // 每个元素细虚线框
    for (i = 0; i < sel.length; i++) {
      r = getRect(sel[i]);
      drawBox(r, true, false);
    }
    // 组包围盒
    var L = Infinity, Tp = Infinity, R = -Infinity, B = -Infinity;
    for (i = 0; i < sel.length; i++) {
      r = getRect(sel[i]);
      L = Math.min(L, r.left); Tp = Math.min(Tp, r.top);
      R = Math.max(R, r.right); B = Math.max(B, r.bottom);
    }
    drawBox({ left: L, top: Tp, right: R, bottom: B, width: R - L, height: B - Tp }, false, true);
    // 组缩放（全为 HTML 元素时）
    if (sel.every(function (el) { return !isSvg(el) || isLineEl(el); })) {
      drawHandles({ left: L, top: Tp, right: R, bottom: B, width: R - L, height: B - Tp });
    }
  }
  callUi('onSelChange');
}
DE.refreshSel = refreshSel;

function drawBox(r, dashed, group) {
  var b = doc.createElement('div');
  b.setAttribute('data-de-ui', '1');
  b.className = 'de-selbox' + (dashed ? ' de-dash' : '') + (group ? ' de-group' : '');
  b.style.left = r.left + 'px'; b.style.top = r.top + 'px';
  b.style.width = Math.max(0, r.width) + 'px'; b.style.height = Math.max(0, r.height) + 'px';
  boxLayer.appendChild(b);
  return b;
}
function drawHandles(r) {
  var names = ['nw', 'n', 'ne', 'w', 'e', 'sw', 's', 'se'];
  var cx = (r.left + r.right) / 2, cy = (r.top + r.bottom) / 2;
  for (var i = 0; i < names.length; i++) {
    var n = names[i];
    var h = doc.createElement('div');
    h.setAttribute('data-de-ui', '1');
    h.className = 'de-h de-h-' + n + (n.length === 1 ? ' de-ned' : '');
    h.setAttribute('data-h', n);
    h.style.left = (n.indexOf('w') >= 0 ? r.left : (n.indexOf('e') >= 0 ? r.right : cx)) + 'px';
    h.style.top = (n.indexOf('n') >= 0 ? r.top : (n.indexOf('s') >= 0 ? r.bottom : cy)) + 'px';
    boxLayer.appendChild(h);
  }
}
function canResize(el) {
  if (isLineEl(el)) return false;
  if (el.dataset && el.dataset.deNoResize) return false;
  return true;
}
function isLineEl(el) {
  return !!(el.classList && el.classList.contains('de-line'));
}
function drawLinepts(el) {
  var eps = el.querySelectorAll('.de-ep');
  for (var i = 0; i < eps.length; i++) {
    var c = eps[i];
    var p = c.getBoundingClientRect();
    var d = doc.createElement('div');
    d.setAttribute('data-de-ui', '1');
    d.className = 'de-eppt';
    d.style.left = (p.left + p.width / 2) + 'px';
    d.style.top = (p.top + p.height / 2) + 'px';
    boxLayer.appendChild(d);
  }
}

function callUi(fn, a, b) {
  var ui = DE.ui;
  if (ui && typeof ui[fn] === 'function') ui[fn](a, b);
}

/* ==================== 引擎：变换 ==================== */
function ensureT(el) {
  var st = T.get(el);
  if (!st) {
    st = { tx: 0, ty: 0, s: 1, orig: el.style.transform || '' };
    T.set(el, st);
  }
  return st;
}
function ensureTS(el) {
  var st = TS.get(el);
  if (!st) {
    st = { tx: 0, ty: 0, s: 1, orig: el.getAttribute('transform') || '' };
    TS.set(el, st);
  }
  return st;
}
function applyHTML(el) {
  var st = ensureT(el);
  el.style.transformOrigin = '0 0';
  var t = 'translate(' + st.tx + 'px,' + st.ty + 'px)';
  if (st.s !== 1) t += ' scale(' + st.s + ')';
  el.style.transform = t + (st.orig ? ' ' + st.orig : '');
}
function applySVG(el) {
  var st = ensureTS(el);
  var t = 'translate(' + st.tx + ' ' + st.ty + ')';
  if (st.s !== 1) {
    var b = el.getBBox();
    var cx = b.x + b.width / 2, cy = b.y + b.height / 2;
    t += ' translate(' + cx + ' ' + cy + ') scale(' + st.s + ') translate(' + (-cx) + ' ' + (-cy) + ')';
  }
  el.setAttribute('transform', t + (st.orig ? ' ' + st.orig : ''));
}
/* 屏幕位移 -> SVG 用户单位 */
function svgDelta(el, dx, dy) {
  var svg = el.ownerSVGElement;
  if (!svg) return { x: dx, y: dy };
  var m = svg.getScreenCTM();
  if (!m) return { x: dx, y: dy };
  var inv = m.inverse();
  return { x: inv.a * dx + inv.c * dy, y: inv.b * dx + inv.d * dy };
}

/* ==================== 引擎：快照 / 撤销 ==================== */
/* 逐元素快照：绝不重建 DOM（deck 自己的闭包引用保持有效），
 * 只记录可改属性（style / SVG 属性）+ 叶子文本 + 原位置（parent/next）。 */
var SVG_ATTRS = ['font-size', 'font-weight', 'fill', 'stroke', 'stroke-width', 'stroke-dasharray', 'marker-end', 'x1', 'y1', 'x2', 'y2', 'cx', 'cy'];

function elSnapshot(el) {
  var st = {
    el: el,
    style: el.getAttribute ? el.getAttribute('style') : null,
    attrs: null,
    text: null,
    contentNodes: null,
    textNodes: null,
    parent: el.parentNode,
    next: el.nextSibling
  };
  if (isSvg(el)) {
    var a = {};
    for (var i = 0; i < SVG_ATTRS.length; i++) {
      var k = SVG_ATTRS[i];
      if (el.hasAttribute(k)) a[k] = el.getAttribute(k);
    }
    st.attrs = a;
  }
  if (canEditText(el) && !isSvg(el)) {
    st.contentNodes = Array.from(el.childNodes);
    st.textNodes = st.contentNodes.filter(function(n){return n.nodeType === 3;}).map(function(n){return {node:n,value:n.nodeValue};});
  } else if (!el.firstElementChild || el.tagName === 'text') st.text = el.textContent;
  return st;
}
function treeWalk(root, out) {
  var kids = root.children || [];
  for (var i = 0; i < kids.length; i++) {
    out.push(kids[i]);
    treeWalk(kids[i], out);
  }
  return out;
}
function snap() {
  if (DE.Persist && DE.Persist.beforeEdit) { try { DE.Persist.beforeEdit(); } catch (e) {} }
  if (!deckEl) return;
  var els = treeWalk(deckEl, []);
  var items = [];
  for (var i = 0; i < els.length; i++) items.push(elSnapshot(els[i]));
  stack.push({ items: items, gen: domGen });
  if (stack.length > 30) stack.shift();
  lastActionT = Date.now();
}
DE.snap = snap;
function snapLazy(winMs) {
  var now = Date.now();
  if (now - lastActionT > (winMs || 800)) snap();
  else lastActionT = now;
}
function undo() {
  while (stack.length && stack[stack.length - 1].gen !== domGen) stack.pop();
  if (!stack.length) {
    if (DE.Persist && DE.Persist.tryRevert && DE.Persist.tryRevert()) { toast('已撤销'); return; }
    toast('没有可撤销的操作');
    return;
  }
  if (!deckEl) return;
  endEdit();
  var s = stack.pop();
  /* 1) 删除快照之后新增的元素（如插入的标注） */
  var before = new Set();
  for (var i = 0; i < s.items.length; i++) before.add(s.items[i].el);
  var nowEls = treeWalk(deckEl, []);
  for (var j = 0; j < nowEls.length; j++) {
    if (!before.has(nowEls[j])) nowEls[j].remove();
  }
  /* 2) 按先序恢复（父先于子）：插回缺失 -> style -> SVG 属性 -> 文本 */
  for (var k = 0; k < s.items.length; k++) {
    var it = s.items[k], el = it.el;
    if (!el.isConnected && it.parent) {
      if (it.next && it.next.parentNode === it.parent) it.parent.insertBefore(el, it.next);
      else it.parent.appendChild(el);
    }
    if (it.style === null) el.removeAttribute('style');
    else el.setAttribute('style', it.style);
    if (it.attrs) {
      for (var m = 0; m < SVG_ATTRS.length; m++) {
        var kk = SVG_ATTRS[m];
        if (it.attrs[kk] === undefined) el.removeAttribute(kk);
        else el.setAttribute(kk, it.attrs[kk]);
      }
    }
    if (it.contentNodes) {
      while (el.firstChild) el.removeChild(el.firstChild);
      it.contentNodes.forEach(function(n){el.appendChild(n);});
      it.textNodes.forEach(function(v){v.node.nodeValue=v.value;});
    } else if (it.text !== null && el.textContent !== it.text) el.textContent = it.text;
  }
  T.clear(); TS.clear();
  sel.length = 0;
  refreshSel();
  pdDirty();
  toast('已撤销');
}
DE.undo = undo;

/* ==================== 引擎：文本编辑 ==================== */
function canEditText(el) {
  if (isSvg(el)) return el.tagName === 'text';
  if (el.hasAttribute && el.hasAttribute('data-de-noedit')) return false;
  if (!el || /^(INPUT|TEXTAREA|SELECT|SCRIPT|STYLE|IMG|SVG)$/.test(el.tagName)) return false;
  if (!(el.textContent || '').trim()) return false;
  if (el.childElementCount === 0) return true;
  if (!/^(P|H[1-6]|SPAN|BUTTON|LABEL|LI|TD|TH|BLOCKQUOTE|STRONG|EM|DIV)$/.test(el.tagName)) return false;
  return Array.from(el.querySelectorAll('*')).every(function (n) { return /^(BR|SPAN|STRONG|B|EM|I|U|SMALL|CODE|SUP|SUB)$/.test(n.tagName); });
}
function htmlEdit(el) {
  if (editing === el) return;
  endEdit();
  select(el);
  snap();
  editing = el;
  el.setAttribute('contenteditable', 'true');
  el.focus();
  try {
    var r = doc.createRange();
    r.selectNodeContents(el); r.collapse(false);
    var s = win.getSelection();
    s.removeAllRanges(); s.addRange(r);
  } catch (e) {}
  var onBlur = function () {
    el.removeEventListener('blur', onBlur);
    if (editing === el) endEdit();
  };
  el.addEventListener('blur', onBlur);
  refreshSel();
}
function svgTextEdit(el) {
  endEdit();
  snap();
  var rect = getRect(el);
  var input = doc.createElement('input');
  input.setAttribute('data-de-ui', '1');
  input.className = 'de-textinp';
  input.value = el.textContent;
  var fs = parseFloat(win.getComputedStyle(el).fontSize) || 16;
  input.style.left = Math.max(4, rect.left - 10) + 'px';
  input.style.top = Math.max(4, rect.top - 6) + 'px';
  input.style.width = Math.max(80, rect.width + 70) + 'px';
  input.style.fontSize = clamp(fs, 10, 30) + 'px';
  doc.body.appendChild(input);
  input.focus(); input.select();
  var orig = el.textContent;
  input.addEventListener('input', function () {
    el.textContent = input.value;
    pdDirty();
    refreshSel();
  });
  input.addEventListener('keydown', function (ev) {
    ev.stopPropagation();
    if (ev.key === 'Enter') { input.blur(); }
    if (ev.key === 'Escape') { el.textContent = orig; input.blur(); }
  });
  input.addEventListener('blur', function () {
    if (input.parentNode) input.parentNode.removeChild(input);
    pdDirty();
    refreshSel();
    callUi('onSelChange');
  });
}
function endEdit() {
  if (!editing) return;
  editing.removeAttribute('contenteditable');
  editing = null;
  pdDirty();
  refreshSel();
}
DE.endEdit = endEdit;
DE.startEdit = htmlEdit;
DE.canEditText = canEditText;
function isNavigation(t) {
  return !!(t.closest && (t.closest('.hud,nav,.footer,.top,#prev,#next,#dots,[data-de-nav]') || t.closest('[data-action="goto"],[data-action="prev"],[data-action="next"],[data-action="menu"],[data-action="notes"],[data-action="fullscreen"],[data-action="help"]')));
}
DE.setMode = function (mode) {
  endEdit(); clearSel(); clearHover(); pending = null; drag = null;
  DE.mode = mode === 'preview' ? 'preview' : 'edit';
  var editBtn = $id('btnModeEdit'), previewBtn = $id('btnModePreview');
  if (editBtn) editBtn.setAttribute('aria-pressed', String(DE.mode === 'edit'));
  if (previewBtn) previewBtn.setAttribute('aria-pressed', String(DE.mode === 'preview'));
  if (doc) doc.documentElement.setAttribute('data-de-mode', DE.mode);
  if (DE.ui && DE.ui.setMode) DE.ui.setMode(DE.mode);
  if (DE.Shell && DE.Shell.setMode) DE.Shell.setMode(DE.mode);
};
function guardClick(e) {
  var t = e.target;
  if (DE.mode !== 'edit' || !t || isUiEl(t) || isNavigation(t)) return;
  if (t.closest && t.closest('input,textarea,select')) return;
  e.preventDefault(); e.stopImmediatePropagation();
}
DE.parentOf = parentOf;
DE.snapLazy = snapLazy;

/* ==================== 引擎：指针交互 ==================== */
function onPointerDown(e) {
  if (DE.mode === 'preview') return;
  if (!e.isPrimary || e.button !== 0) return;
  var t = e.target;
  if (!t || t.nodeType !== 1) return;

  if (editing && (t === editing || editing.contains(t))) return;
  /* 文本编辑中点到别处：先收尾编辑（保证重画/保存前来得及记录修改） */
  if (editing && t !== editing && !editing.contains(t)) endEdit();

  /* 角手柄 -> 缩放 */
  var h = t.closest ? t.closest('.de-h') : null;
  if (h) { startResize(e, h); return; }
  /* 线端点 */
  var ep = t.closest ? t.closest('.de-ep') : null;
  if (ep) { startLineEnd(e, ep); return; }
  /* 编辑器 UI、deck HUD -> 放行 */
  if (isUiEl(t)) return;
  if (isNavigation(t) || (t.closest && t.closest('input,textarea,select'))) return;

  var el = hitEl(e);
  if (!el) { clearSel(); return; }

  if (e.shiftKey) { toggleSel(el); return; }

  if (sel.length && sel.indexOf(el) >= 0) {
    /* 点住已选中元素：可能是拖动 / 或点击选父 */
    pending = { el: el, x: e.clientX, y: e.clientY, moved: false, isSel: true };
    return;
  }
  select(el);
  pending = { el: el, x: e.clientX, y: e.clientY, moved: false, isSel: false };
}

function startDrag(e) {
  snap();
  drag = {
    mode: 'move',
    x0: e.clientX, y0: e.clientY,
    items: sel.map(function (el) {
      if (isLineEl(el)) {
        return { el: el, l0: parseFloat(el.style.left) || 0, t0: parseFloat(el.style.top) || 0, kind: 'line' };
      }
      if (el.dataset && el.dataset.deAnno && !isSvg(el)) {
        return { el: el, l0: parseFloat(el.style.left) || 0, t0: parseFloat(el.style.top) || 0, kind: 'abs' };
      }
      if (isSvg(el)) {
        var st = ensureTS(el);
        return { el: el, tx0: st.tx, ty0: st.ty, kind: 'svg' };
      }
      var st2 = ensureT(el);
      return { el: el, tx0: st2.tx, ty0: st2.ty, kind: 'html' };
    })
  };
}

function onPointerMove(e) {
  if (DE.mode === 'preview') return;
  /* 拖动中 */
  if (drag) {
    var dx = e.clientX - drag.x0, dy = e.clientY - drag.y0;
    drag.items.forEach(function (it) {
      if (it.kind === 'line' || it.kind === 'abs') {
        var K1 = Kof(it.el);
        it.el.style.left = (it.l0 + dx / K1) + 'px';
        it.el.style.top = (it.t0 + dy / K1) + 'px';
      } else if (it.kind === 'svg') {
        var d = svgDelta(it.el, dx, dy);
        var st = ensureTS(it.el);
        st.tx = it.tx0 + d.x; st.ty = it.ty0 + d.y;
        applySVG(it.el);
      } else {
        var K2 = Kof(it.el);
        var st2 = ensureT(it.el);
        st2.tx = it.tx0 + dx / K2; st2.ty = it.ty0 + dy / K2;
        applyHTML(it.el);
      }
    });
    refreshSel();
    return;
  }
  if (resizeState) { doResize(e); return; }
  if (lineEndState) { doLineEnd(e); return; }

  /* 待判定：拖动阈值 */
  if (pending && !pending.moved) {
    var ddx = e.clientX - pending.x, ddy = e.clientY - pending.y;
    if (ddx * ddx + ddy * ddy > 9) {
      pending.moved = true;
      if (!pending.isSel) lastClickEl = pending.el;
      startDrag({ clientX: pending.x, clientY: pending.y });
    }
  }

  /* hover 高亮 */
  if (!pending && !drag) {
    var t = e.target;
    var h = (t && t.nodeType === 1 && t.closest) ? (isUiEl(t) || isNavigation(t) ? null : hitEl(e)) : null;
    if (h !== hoverEl) {
      unhover(hoverEl);
      hoverEl = h;
      if (hoverEl && sel.indexOf(hoverEl) < 0) hoverEl.classList.add('de-hover');
    }
  }
}

function onPointerUp(e) {
  if (drag) { drag = null; pending = null; pdDirty(); refreshSel(); return; }
  if (resizeState) { resizeState = null; pending = null; pdDirty(); refreshSel(); return; }
  if (lineEndState) { lineEndState = null; pending = null; pdDirty(); refreshSel(); return; }
  if (pending) {
    if (!pending.moved && pending.isSel) {
      if (sel.length > 1) {
        select(pending.el);          /* 多选点其一 -> 收缩为单选 */
      } else {
        var p = parentOf(pending.el); /* 点击已选中 -> 选父级 */
        if (p !== pending.el) select(p);
      }
    }
    pending = null;
  }
}

/* ---- 缩放 ---- */
var resizeState = null;
function startResize(e, h) {
  var dir = h.getAttribute('data-h');
  snap();
  resizeState = {
    dir: dir,
    x0: e.clientX, y0: e.clientY,
    items: [],
    A: null
  };
  var i, r;
  if (sel.length === 1) {
    r = getRect(sel[0]);
  } else {
    var L = Infinity, Tp = Infinity, R = -Infinity, B = -Infinity;
    for (i = 0; i < sel.length; i++) {
      var rr = getRect(sel[i]);
      L = Math.min(L, rr.left); Tp = Math.min(Tp, rr.top);
      R = Math.max(R, rr.right); B = Math.max(B, rr.bottom);
    }
    r = { left: L, top: Tp, right: R, bottom: B, width: R - L, height: B - Tp };
  }
  /* 锚点 = 对角 */
  var anchors = {
    nw: { x: r.right, y: r.bottom }, ne: { x: r.left, y: r.bottom },
    sw: { x: r.right, y: r.top }, se: { x: r.left, y: r.top },
    n: { x: r.left, y: r.bottom }, s: { x: r.left, y: r.top },
    w: { x: r.right, y: r.top }, e: { x: r.left, y: r.top }
  };
  resizeState.A = anchors[dir];
  var K = DE.getK();
  if (sel.length === 1) {
    var el = sel[0];
    var da = el.dataset && el.dataset.deAnno;
    if (da === 'box' || da === 'circle' || da === 'roundrect' || da === 'img') {
      /* 方框：改 left/top/width/height */
      resizeState.items.push({
        kind: 'box', el: el,
        l0: parseFloat(el.style.left) || 0, t0: parseFloat(el.style.top) || 0,
        w0: el.offsetWidth, h0: el.offsetHeight
      });
    } else if (!isSvg(el) && ((el.dataset && el.dataset.deAnno === 'text') || canEditText(el))) {
      var css = win.getComputedStyle(el), tr = getRect(el), ts = ensureT(el);
      resizeState.items.push({
        kind: 'textbox', el: el, abs: /^(absolute|fixed)$/.test(css.position),
        l0: parseFloat(css.left) || el.offsetLeft || 0, t0: parseFloat(css.top) || el.offsetTop || 0,
        w0: el.offsetWidth || tr.width / Kof(el), h0: el.offsetHeight || tr.height / Kof(el),
        sizeK: el.offsetWidth ? tr.width / el.offsetWidth : Kof(el), posK: Kof(el),
        tx0: ts.tx, ty0: ts.ty
      });
    } else if (isSvg(el)) {
      var st = ensureTS(el);
      resizeState.items.push({ kind: 'svg1', el: el, s0: st.s });
    } else {
      var st2 = ensureT(el);
      resizeState.items.push({ kind: 'html1', el: el, tx0: st2.tx, ty0: st2.ty, s0: st2.s });
    }
  } else {
    for (i = 0; i < sel.length; i++) {
      var e2 = sel[i];
      if (isSvg(e2)) continue; /* 多选缩放：SVG 只跟随位移（v1） */
      var st3 = ensureT(e2);
      var rr2 = getRect(e2);
      resizeState.items.push({
        kind: 'htmlN', el: e2, tx0: st3.tx, ty0: st3.ty, s0: st3.s,
        P0: { x: rr2.left, y: rr2.top }
      });
    }
  }
}

function doResize(e) {
  var rs = resizeState;
  var mx = e.clientX, my = e.clientY;
  var A = rs.A;
  if (!rs.lambda0) {
    rs.lambda0 = Math.hypot(rs.x0 - A.x, rs.y0 - A.y);
    if (rs.lambda0 < 6) rs.lambda0 = 6;
  }
  var lam = Math.hypot(mx - A.x, my - A.y) / rs.lambda0;
  lam = clamp(lam, 0.1, 8);

  rs.items.forEach(function (it) {
    if (it.kind === 'box' || it.kind === 'textbox') {
      /* 自由缩放：角手柄改双边（按 Shift 等比）、边手柄改单边；对角/对边为不动点 */
      var dir = rs.dir;
      var sx = dir.indexOf('e') >= 0 ? 1 : (dir.indexOf('w') >= 0 ? -1 : 0);
      var sy = dir.indexOf('s') >= 0 ? 1 : (dir.indexOf('n') >= 0 ? -1 : 0);
      var K = it.kind === 'textbox' ? (it.sizeK || 1) : Kof(it.el);
      var dx = (mx - rs.x0) / K, dy = (my - rs.y0) / K;
      var w = it.w0 + sx * dx;
      var h = it.h0 + sy * dy;
      if (dir.length === 2 && e.shiftKey) {
        var lamEq = Math.max(w / it.w0, h / it.h0);
        lamEq = clamp(lamEq, 0.05, 10);
        w = it.w0 * lamEq; h = it.h0 * lamEq;
      }
      w = Math.max(24, w); h = Math.max(24, h);
      it.el.style.width = w + 'px';
      it.el.style.height = h + 'px';
      if (it.kind === 'textbox') {
        it.el.style.boxSizing = 'border-box';
        it.el.style.maxWidth = 'none'; it.el.style.minWidth = '0';
        it.el.style.minHeight = '0'; it.el.style.flexShrink = '0';
        if (win.getComputedStyle(it.el).display === 'inline') it.el.style.display = 'inline-block';
        if (win.getComputedStyle(it.el).whiteSpace === 'nowrap') it.el.style.whiteSpace = 'pre-wrap';
        it.el.style.overflowWrap = 'break-word';
        var ox = sx < 0 ? (it.w0 - w) * K / (it.posK || 1) : 0;
        var oy = sy < 0 ? (it.h0 - h) * K / (it.posK || 1) : 0;
        if (it.abs) {
          if (sx < 0) it.el.style.left = (it.l0 + ox) + 'px';
          if (sy < 0) it.el.style.top = (it.t0 + oy) + 'px';
        } else if (sx < 0 || sy < 0) {
          var textT = ensureT(it.el); textT.tx = it.tx0 + ox; textT.ty = it.ty0 + oy; applyHTML(it.el);
        }
      } else {
        if (sx < 0) it.el.style.left = (it.l0 + (it.w0 - w)) + 'px';
        if (sy < 0) it.el.style.top = (it.t0 + (it.h0 - h)) + 'px';
      }
    } else if (it.kind === 'svg1') {
      var st = ensureTS(it.el);
      st.s = clamp(it.s0 * lam, 0.15, 6);
      applySVG(it.el);
    } else if (it.kind === 'html1') {
      var st2 = ensureT(it.el);
      st2.s = clamp(it.s0 * lam, 0.15, 6);
      st2.tx = it.tx0; st2.ty = it.ty0;
      applyHTML(it.el);
    } else if (it.kind === 'htmlN') {
      var st3 = ensureT(it.el);
      var lamEff = clamp(lam, 0.15 / (it.s0 || 1), 6 / (it.s0 || 1));
      st3.s = clamp(it.s0 * lam, 0.15, 6);
      var lEff = it.s0 ? (st3.s / it.s0) : 1;
      var KK = Kof(it.el);
      st3.tx = it.tx0 + (lEff - 1) * (it.P0.x - A.x) / KK;
      st3.ty = it.ty0 + (lEff - 1) * (it.P0.y - A.y) / KK;
      applyHTML(it.el);
    }
  });
  refreshSel();
}

/* ---- 线端点拖拽 ---- */
var lineEndState = null;
function startLineEnd(e, ep) {
  snap();
  var lineEl = ep.closest('.de-line');
  var which = ep.getAttribute('data-ep');
  var v = lineEl.querySelector('.vis');
  lineEndState = {
    line: lineEl, ep: which, x0: e.clientX, y0: e.clientY,
    x1: parseFloat(v.getAttribute('x1')) || 0, y1: parseFloat(v.getAttribute('y1')) || 0,
    x2: parseFloat(v.getAttribute('x2')) || 0, y2: parseFloat(v.getAttribute('y2')) || 0,
    l0: parseFloat(lineEl.style.left) || 0, t0: parseFloat(lineEl.style.top) || 0,
    cx2: parseFloat((lineEl.querySelector('[data-ep="2"]') || {getAttribute:function(){return 0}}).getAttribute('cx')) || 0,
    cy2: parseFloat((lineEl.querySelector('[data-ep="2"]') || {getAttribute:function(){return 0}}).getAttribute('cy')) || 0
  };
}
function doLineEnd(e) {
  var ls = lineEndState;
  var K = Kof(ls.line);
  var dx = (e.clientX - ls.x0) / K, dy = (e.clientY - ls.y0) / K;
  var v = ls.line.querySelector('.vis');
  var hit = ls.line.querySelector('.hit');
  if (ls.ep === '2') {
    var nx = ls.x2 + dx, ny = ls.y2 + dy;
    v.setAttribute('x2', nx); v.setAttribute('y2', ny);
    hit.setAttribute('x2', nx); hit.setAttribute('y2', ny);
    var c2 = ls.line.querySelector('[data-ep="2"]');
    c2.setAttribute('cx', nx); c2.setAttribute('cy', ny);
  } else {
    var nx1 = ls.x1 + dx, ny1 = ls.y1 + dy;
    /* 起点移动 = 整体平移（保持终点不动）；全部以拖动起点快照为基准，避免重复累加 */
    var offx = nx1, offy = ny1;
    ls.line.querySelectorAll('.vis,.hit').forEach(function (ln) {
      ln.setAttribute('x1', 0); ln.setAttribute('y1', 0);
      ln.setAttribute('x2', ls.x2 - offx);
      ln.setAttribute('y2', ls.y2 - offy);
    });
    ls.line.querySelector('[data-ep="1"]').setAttribute('cx', 0);
    ls.line.querySelector('[data-ep="1"]').setAttribute('cy', 0);
    ls.line.querySelector('[data-ep="2"]').setAttribute('cx', ls.cx2 - offx);
    ls.line.querySelector('[data-ep="2"]').setAttribute('cy', ls.cy2 - offy);
    ls.line.style.left = (ls.l0 + offx) + 'px';
    ls.line.style.top = (ls.t0 + offy) + 'px';
  }
  refreshSel();
}

/* ==================== 引擎：键盘 ==================== */
function isInputFocus() {
  var a = doc.activeElement;
  if (!a) return false;
  if (a.isContentEditable) return true;
  var tag = a.tagName;
  return tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT';
}
function onKeyDown(e) {
  if (DE.mode === 'preview' || isUiEl(e.target)) return;
  if (isInputFocus()) {
    /* 编辑态：Escape 结束编辑并清选（其余键原生） */
    if (e.key === 'Escape') {
      var a = doc.activeElement;
      if (a && a.isContentEditable && a.blur) a.blur();
      setTimeout(function () { clearSel(); }, 0);
    }
    return;
  }
  var k = e.key;
  if ((e.metaKey || e.ctrlKey) && (k === 'z' || k === 'Z')) {
    e.preventDefault(); e.stopPropagation();
    undo();
    return;
  }
  if (k === 'Escape') {
    if (sel.length) { e.preventDefault(); e.stopPropagation(); clearSel(); }
    return;
  }
  if (sel.length && (k === 'ArrowUp' || k === 'ArrowDown' || k === 'ArrowLeft' || k === 'ArrowRight')) {
    e.preventDefault(); e.stopPropagation();
    var step = e.shiftKey ? 10 : 1;
    var dx = k === 'ArrowLeft' ? -step : k === 'ArrowRight' ? step : 0;
    var dy = k === 'ArrowUp' ? -step : k === 'ArrowDown' ? step : 0;
    snapLazy(700);
    sel.forEach(function (el) {
      var K = Kof(el);
      if (isLineEl(el)) {
        el.style.left = ((parseFloat(el.style.left) || 0) + dx / K) + 'px';
        el.style.top = ((parseFloat(el.style.top) || 0) + dy / K) + 'px';
      } else if (el.dataset && el.dataset.deAnno && !isSvg(el)) {
        el.style.left = ((parseFloat(el.style.left) || 0) + dx / K) + 'px';
        el.style.top = ((parseFloat(el.style.top) || 0) + dy / K) + 'px';
      } else if (isSvg(el)) {
        var d = svgDelta(el, dx, dy);
        var st = ensureTS(el);
        st.tx += d.x; st.ty += d.y;
        applySVG(el);
      } else {
        var st2 = ensureT(el);
        st2.tx += dx / K; st2.ty += dy / K;
        applyHTML(el);
      }
    });
    pdDirty();
    refreshSel();
    return;
  }
  /* 其余放行：deck 翻页等 */
}

/* ==================== 引擎：初始化 ==================== */
var ENGINE_CSS = [
'.de-selbox{position:fixed;border:1.5px solid #4E8AE8;pointer-events:none;z-index:2147482000;box-shadow:0 0 0 1px rgba(78,138,232,.25);border-radius:2px;}',
'.de-selbox.de-dash{border-style:dashed;border-color:#7FA8E8;}',
'.de-selbox.de-group{border-width:1.5px;border-color:#4E8AE8;background:rgba(78,138,232,.04);}',
'.de-h{position:fixed;width:10px;height:10px;background:#fff;border:2px solid #4E8AE8;border-radius:2px;pointer-events:auto;z-index:2147482001;margin:-6px 0 0 -6px;}',
'.de-h.de-ned{width:8px;height:8px;margin:-5px 0 0 -5px;border-width:1.5px;}',
'.de-h-nw{cursor:nwse-resize;} .de-h-se{cursor:nwse-resize;}',
'.de-h-ne{cursor:nesw-resize;} .de-h-sw{cursor:nesw-resize;}',
'.de-h-n{cursor:ns-resize;} .de-h-s{cursor:ns-resize;}',
'.de-h-e{cursor:ew-resize;} .de-h-w{cursor:ew-resize;}',
'.de-eppt{position:fixed;width:12px;height:12px;margin:-7px 0 0 -7px;border-radius:50%;background:#fff;border:2.5px solid #4E8AE8;pointer-events:none;z-index:2147482001;}',
'.de-hover{outline:1.5px solid rgba(78,138,232,.55) !important;outline-offset:1px;}',
'.de-textinp{position:fixed;z-index:2147482100;background:#fff;border:1.5px solid #4E8AE8;border-radius:4px;padding:4px 8px;font-family:inherit;color:#16233A;box-shadow:0 4px 16px rgba(0,0,0,.18);outline:none;}'
].join('\n');

function initEngine() {
  doc = ifr.contentDocument;
  win = ifr.contentWindow;
  if (!doc) { toast('无法访问文档（浏览器限制）', 5000); return; }
  try { win.__deEditorHost = true; } catch (e) {}
  deckEl = doc.getElementById('deck') || doc.getElementById('stage') || doc.body;

  /* 注入引擎样式 */
  var old = doc.getElementById('de-style');
  if (old) old.parentNode.removeChild(old);
  var st = doc.createElement('style');
  st.id = 'de-style';
  st.textContent = ENGINE_CSS;
  doc.head.appendChild(st);

  /* 覆盖层 */
  var bl = doc.createElement('div');
  bl.setAttribute('data-de-ui', '1');
  bl.id = 'de-boxlayer';
  bl.style.cssText = 'position:fixed;inset:0;pointer-events:none;z-index:2147482000;';
  doc.body.appendChild(bl);
  boxLayer = bl;

  /* 事件（capture 优先于 deck 自身监听） */
  doc.addEventListener('click', guardClick, true);
  doc.addEventListener('pointerdown', onPointerDown, true);
  doc.addEventListener('pointermove', onPointerMove, true);
  doc.addEventListener('pointerup', onPointerUp, true);
  doc.addEventListener('keydown', onKeyDown, true);
  doc.addEventListener('dblclick', function (e) {
    var t = e.target;
    if (!t || t.nodeType !== 1) return;
    if (DE.mode === 'preview' || isUiEl(t) || isNavigation(t)) return;
    var el = hitEl(e);
    if (!el) return;
    if (isSvg(el)) {
      if (el.tagName === 'text') { e.preventDefault(); e.stopPropagation(); svgTextEdit(el); }
    } else if (canEditText(el)) {
      e.preventDefault(); e.stopPropagation();
      htmlEdit(el);
    }
  }, true);
  win.addEventListener('resize', function () { refreshSel(); });

  /* 翻页 -> 清选中 */
  var mo = new win.MutationObserver(function (muts) {
    for (var i = 0; i < muts.length; i++) {
      var tg = muts[i].target;
      if (tg && tg.classList && tg.classList.contains('slide')) {
        if (sel.length || hoverEl || editing) {
          if (editing) endEdit();
          sel.length = 0;
          if (hoverEl) { hoverEl.classList.remove('de-hover'); hoverEl = null; }
          refreshSel();
        }
        return;
      }
    }
  });
  mo.observe(deckEl, { attributes: true, attributeFilter: ['class'], subtree: true });

  /* UI 层（toolbar 等） */
  if (DE.ui && typeof DE.ui.attach === 'function') DE.ui.attach(doc, win);

  /* 修改保持层：针对“翻页/交互会重画内容”的 deck（客户端渲染型） */
  try { if (DE.Persist && DE.Persist.init) DE.Persist.init(doc, win); }
  catch (e) { console.warn('[deck-editor] persist init failed', e); }

  DE.setMode(DE.mode);
  refreshSel();
  console.log('[deck-editor] engine ready, deck =', deckEl.id || deckEl.tagName);
}

/* ==================== 父层交互绑定 ==================== */
function bindTop() {
  if ($id('btnModeEdit')) $id('btnModeEdit').addEventListener('click', function () { DE.setMode('edit'); });
  if ($id('btnModePreview')) $id('btnModePreview').addEventListener('click', function () { DE.setMode('preview'); });
  $id('fileInput').addEventListener('change', function () {
    if (this.files && this.files[0]) openFile(this.files[0]);
    this.value = '';
  });
  $id('btnReload').addEventListener('click', function () {
    if (!S.text) return;
    if (DE.hasEdits && DE.hasEdits() && !window.confirm('重新载入将放弃当前所有修改，确定吗？')) return;
    load(S.text, S.name, S.url);
    toast('已重新载入');
  });
  $id('btnOpenUrl').addEventListener('click', function () {
    $id('urlDlg').classList.add('show');
    var inp = $id('urlInput');
    inp.value = S.url || '';
    setTimeout(function () { inp.focus(); inp.select(); }, 50);
  });
  $id('urlCancel').addEventListener('click', function () { $id('urlDlg').classList.remove('show'); });
  $id('urlGo').addEventListener('click', function () {
    var u = $id('urlInput').value.trim();
    if (!u) return;
    $id('urlDlg').classList.remove('show');
    loadFromUrl(u);
  });
  $id('urlInput').addEventListener('keydown', function (e) {
    if (e.key === 'Enter') $id('urlGo').click();
    if (e.key === 'Escape') $id('urlCancel').click();
  });
  /* 使用说明面板 */
  $id('btnHelp').addEventListener('click', function () {
    var dlg = $id('helpDlg');
    dlg.classList.add('show');
    var b = dlg.querySelector('.hbody');
    if (b) b.scrollTop = 0;
  });
  $id('helpClose').addEventListener('click', function () { $id('helpDlg').classList.remove('show'); });
  $id('helpDlg').addEventListener('click', function (e) {
    if (e.target === this) this.classList.remove('show');
  });
  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape' && $id('helpDlg').classList.contains('show')) {
      $id('helpDlg').classList.remove('show');
    }
  });
  $id('btnSaveTop').addEventListener('click', function () {
    if (DE.ui && DE.ui.download) DE.ui.download();
  });
  /* 拖放：document 级 + capture（父层全覆盖，防浏览器用文件导航/开新标签） */
  var dragDepth = 0;
  document.addEventListener('dragenter', function (e) {
    e.preventDefault();
    dragDepth++;
    document.body.classList.add('dragging');
  }, true);
  document.addEventListener('dragover', function (e) { e.preventDefault(); }, true);
  document.addEventListener('dragleave', function () {
    dragDepth = Math.max(0, dragDepth - 1);
    if (!dragDepth) document.body.classList.remove('dragging');
  }, true);
  document.addEventListener('drop', function (e) {
    e.preventDefault();
    dragDepth = 0;
    document.body.classList.remove('dragging');
    if (e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files[0]) openFile(e.dataTransfer.files[0]);
  }, true);
}

DE.hasEdits = function () { return stack.length > 0 || !!(DE.Persist && DE.Persist.hasEdits && DE.Persist.hasEdits()); };

/* 启动 */
ifr = $id('canvas');
bindTop();
console.log('[deck-editor] core loaded');

})();
