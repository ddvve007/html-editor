/* Dynamic HTML: replay only edited fields, keyed by page + element + original content.
 * Do not replace the whole page: original listeners and interaction states remain intact.
 * v1 snapshot exports remain readable; v2 exports store small, guarded patches. */
(function () {
'use strict';
var DE = window.DE = window.DE || {};
window.__dePersistRun = function (cfg) {
  'use strict';
  var W=cfg.win||window,D=cfg.doc||document, selector=cfg.sel;
  var pages=cfg.pages||[],legacy=cfg.store||[],base=null,first=null,root=null,busy=false;
  var tag=D.currentScript;
  var attrs=['style','transform','font-size','font-weight','fill','stroke','stroke-width','stroke-dasharray','marker-end','x1','y1','x2','y2','cx','cy'];
  function dormant(){return !cfg.owner && (W.__deEditorHost || (tag && !tag.isConnected));}
  function clean(el){var n=el.cloneNode(true);n.querySelectorAll('[data-de-ui]').forEach(function(x){x.remove();});[n].concat(Array.from(n.querySelectorAll('*'))).forEach(function(x){x.removeAttribute('contenteditable');x.classList.remove('de-hover');if(!x.getAttribute('class'))x.removeAttribute('class');});return n;}
  function cont(){return D.querySelector(selector);}
  function key(c){
    var slides=Array.from(D.querySelectorAll('.slide'));
    if(c.classList.contains('slide'))return 'slide:'+(c.id||slides.indexOf(c));
    var counter=D.querySelector('#page-count,.page-count,[data-page-current]');
    var match=counter && counter.textContent.match(/\d+/);
    if(match)return 'page:'+match[0];
    var eyebrow=c.querySelector('.eyebrow,[data-page-id]');
    if(eyebrow)return 'section:'+eyebrow.textContent.trim();
    return 'document:'+selector;
  }
  function attrQuote(s){return String(s).replace(/\\/g,'\\\\').replace(/"/g,'\\"');}
  function loc(el,c){
    if(el===c)return '';
    var parts=[],n=el;
    while(n && n!==c){
      if(n.id){parts.unshift('[id="'+attrQuote(n.id)+'"]');break;}
      var action=n.getAttribute('data-action'),value=n.getAttribute('data-value');
      if(action && value!==null){parts.unshift('[data-action="'+attrQuote(action)+'"][data-value="'+attrQuote(value)+'"]');break;}
      var siblings=n.parentElement?Array.from(n.parentElement.children).filter(function(x){return x.tagName===n.tagName;}):[];
      parts.unshift(n.tagName.toLowerCase()+':nth-of-type('+(siblings.indexOf(n)+1)+')');n=n.parentElement;
    }
    return parts.join(' > ');
  }
  function resolve(c,l){try{return l?c.querySelector(l):c;}catch(e){return null;}}
  function getPage(k,create){for(var i=0;i<pages.length;i++)if(pages[i].key===k)return pages[i];if(!create)return null;var p={key:k,patches:[],annotations:[]};pages.push(p);return p;}
  function canText(n){if(!n.textContent.trim() || /^(SCRIPT|STYLE|INPUT|TEXTAREA|SELECT|SVG)$/.test(n.tagName))return false;if(!n.children.length)return true;if(!/^(P|H[1-6]|SPAN|BUTTON|LABEL|LI|TD|TH|BLOCKQUOTE|STRONG|EM|DIV)$/.test(n.tagName))return false;return Array.from(n.querySelectorAll('*')).every(function(x){return /^(BR|SPAN|STRONG|B|EM|I|U|SMALL|CODE|SUP|SUB)$/.test(x.tagName);});}
  function capture(c){
    var p=getPage(key(c)),nodes=[c].concat(Array.from(c.querySelectorAll('*'))).filter(function(n){return !n.closest('[data-de-ui],.de-anno');});
    var rows=nodes.map(function(n){var copy=clean(n),a={};attrs.forEach(function(k){a[k]=copy.getAttribute(k);});var row={el:n,loc:loc(n,c),tag:n.tagName,html:copy.innerHTML,text:copy.textContent,attrs:a,editable:canText(copy),parent:n.parentNode,next:n.nextSibling,ancestors:[]};var q=n.parentElement;while(q && q!==c){row.ancestors.push(q);q=q.parentElement;}row.ancestors.push(c);
      /* Reimported files already display edited DOM. Recover the original comparison values. */
      if(p)(p.patches||[]).forEach(function(v){if(v.loc!==row.loc || v.tag!==row.tag)return;if(v.html && row.html===v.html.to){row.html=v.html.from;var t=D.createElement('div');t.innerHTML=row.html;row.text=t.textContent;}if(v.attrs && (row.text===v.guard || (v.html && copy.innerHTML===v.html.to)))Object.keys(v.attrs).forEach(function(k){if(row.attrs[k]===v.attrs[k].to)row.attrs[k]=v.attrs[k].from;});});
      return row;});
    return {c:c,key:key(c),nodes:rows,html:clean(c).innerHTML};
  }
  function hash(s){var a=2166136261,b=5381;for(var i=0;i<s.length;i++){a=((a^s.charCodeAt(i))*16777619)>>>0;b=((b<<5)+b+s.charCodeAt(i))>>>0;}return a.toString(36)+'.'+b.toString(36)+'.'+s.length.toString(36);}
  function replay(c,p){
    if(!p)return;
    (p.patches||[]).forEach(function(v){var el=resolve(c,v.loc);if(!el || el.tagName!==v.tag)return;var original=clean(el);var match=original.textContent===v.guard || (v.html && original.innerHTML===v.html.to);if(!match)return;
      if(v.deleted){if(el!==c)el.remove();return;}
      if(v.html && (original.innerHTML===v.html.from || original.innerHTML===v.html.to))el.innerHTML=v.html.to;
      Object.keys(v.attrs||{}).forEach(function(k){var x=v.attrs[k];if(x.to===null)el.removeAttribute(k);else el.setAttribute(k,x.to);});
    });
    if(p.annotations && p.annotations.length){c.querySelectorAll('.de-anno').forEach(function(n){n.remove();});p.annotations.forEach(function(a){var host=resolve(c,a.host);if(!host)return;var t=D.createElement('template');t.innerHTML=a.html;host.appendChild(t.content.cloneNode(true));});}
  }
  function check(force){
    if(busy||dormant())return;
    var c=cont();if(!c)return;
    if(!force && c===root && c.firstElementChild===first && base && key(c)===base.key)return;
    busy=true;
    try{
      var raw=clean(c).innerHTML,h=hash(raw);
      legacy.forEach(function(v){if(v.h===h && typeof v.c==='string')c.innerHTML=v.c;});
      root=c;base=capture(c);replay(c,getPage(base.key));first=c.firstElementChild;
      if(cfg.onRender)cfg.onRender(base);
    }finally{busy=false;}
  }
  function sync(){root=cont();first=root && root.firstElementChild;}
  var mo=new W.MutationObserver(function(){check(false);});
  mo.observe(D.body,{childList:true,subtree:true,attributes:true,attributeFilter:['class']});
  check(true);
  return {check:check,cont:cont,key:key,loc:loc,resolve:resolve,clean:clean,getPage:getPage,attrs:attrs,pages:pages,sync:sync,getBase:function(){return base;},disconnect:function(){mo.disconnect();}};
};

var P=DE.Persist={doc:null,win:null,selector:null,container:null,pages:[],legacy:[],run:null,base:null,enabled:false,active:null};
P.init=function(doc,win){
  if(P.run)P.run.disconnect();
  P.doc=doc;P.win=win;P.pages=[];P.legacy=[];P.base=null;P.active=null;P.enabled=false;
  var tags=doc.querySelectorAll('script[data-de-persist]'),data=null;
  tags.forEach(function(s){if(s.getAttribute('data-de-persist')==='1'){try{data=JSON.parse(s.textContent);}catch(e){}}});tags.forEach(function(s){s.remove();});
  if(data){P.pages=Array.isArray(data.pages)?data.pages:[];P.legacy=Array.isArray(data.store)?data.store:[];}
  var candidates=[data && data.sel,'#slide','.slide.active','.slide','body'];
  P.selector=candidates.find(function(s){if(!s)return false;try{return !!doc.querySelector(s);}catch(e){return false;}});
  P.container=doc.querySelector(P.selector);P.enabled=!!P.container;
  P.run=window.__dePersistRun({win:win,doc:doc,sel:P.selector,pages:P.pages,store:P.legacy,owner:true,onRender:function(b){P.base=b;P.container=b.c;P.active=P.run?P.run.getPage(b.key,false):null;if(DE.bumpGen)DE.bumpGen();if(DE.clearSel)DE.clearSel();}});
  P.base=P.run.getBase();
};
P.beforeEdit=function(){if(DE.clearHover)DE.clearHover();if(P.run)P.run.check(false);};
P.markDirty=function(){
  if(!P.run || !P.base)return;
  if(DE.clearHover)DE.clearHover();
  var b=P.base,c=P.run.cont();
  if(c!==b.c || P.run.key(c)!==b.key)return;
  if(b.nodes.length>1 && !b.nodes.slice(1).some(function(n){return n.el.isConnected && c.contains(n.el);}))return;
  var p=P.run.getPage(b.key,true),covered=[];
  b.nodes.forEach(function(row){
    var id=row.loc+'\n'+row.tag+'\n'+row.text;
    var oldIndex=(p.patches||[]).findIndex(function(v){return v.loc+'\n'+v.tag+'\n'+v.guard===id;});
    if(covered.some(function(n){return row.ancestors.indexOf(n)>=0;}))return;
    var el=row.el,live=el.isConnected && (el===c || c.contains(el));
    var v={loc:row.loc,tag:row.tag,guard:row.text},changed=false;
    if(!live){v.deleted=true;changed=true;covered.push(el);}
    else{
      var copy=P.run.clean(el);
      if(row.editable && copy.textContent!==row.text){v.html={from:row.html,to:copy.innerHTML};changed=true;covered.push(el);}
      var a={};P.run.attrs.forEach(function(k){var value=copy.getAttribute(k);if(value!==row.attrs[k]){a[k]={from:row.attrs[k],to:value};changed=true;}});if(Object.keys(a).length)v.attrs=a;
    }
    if(oldIndex>=0){if(changed)p.patches[oldIndex]=v;else p.patches.splice(oldIndex,1);}else if(changed)p.patches.push(v);
  });
  p.annotations=Array.from(c.querySelectorAll('.de-anno')).filter(function(n){return !n.parentElement.closest('.de-anno');}).map(function(n){return {host:P.run.loc(n.parentElement,c),html:P.run.clean(n).outerHTML};});
  P.active=p;P.run.sync();
};
P.hasEdits=function(){return P.pages.some(function(p){return p.patches.length || p.annotations.length;}) || P.legacy.length>0;};
P.tryRevert=function(){
  if(!P.base || !P.active)return false;
  var b=P.base,p=P.active;if(!p.patches.length&&!p.annotations.length)return false;
  var covered=[];
  b.nodes.forEach(function(row){var n=row.el;if(covered.some(function(x){return row.ancestors.indexOf(x)>=0;}))return;if(!n.isConnected && row.parent && row.parent.isConnected)row.parent.insertBefore(n,row.next && row.next.parentNode===row.parent?row.next:null);if(!n.isConnected)return;Object.keys(row.attrs).forEach(function(k){if(row.attrs[k]===null)n.removeAttribute(k);else n.setAttribute(k,row.attrs[k]);});if(row.editable){n.innerHTML=row.html;covered.push(n);}});
  b.c.querySelectorAll('.de-anno').forEach(function(n){n.remove();});p.patches=[];p.annotations=[];P.run.sync();return true;
};
P.embed=function(nd){
  P.markDirty();
  var pages=P.pages.filter(function(p){return p.patches.length || p.annotations.length;});
  if(!pages.length && !P.legacy.length)return false;
  var json=JSON.stringify({v:2,sel:P.selector,pages:pages,store:P.legacy}).replace(/</g,'\\u003c');
  var data=nd.createElement('script');data.type='application/json';data.setAttribute('data-de-persist','1');data.textContent=json;
  var runtime=nd.createElement('script');runtime.setAttribute('data-de-persist','2');runtime.textContent='('+window.__dePersistRun.toString()+')('+json+');';
  nd.body.appendChild(data);nd.body.appendChild(runtime);return true;
};
})();
