/* ============================================================
 * HTML 编辑器 — UI 层
 * 工具条 / 色板 / 命令路由 / 标注创建 / 保存
 * ============================================================ */
(function () {
'use strict';
var DE = window.DE;
if (!DE) { console.error('[deck-editor] core 未加载'); return; }
var IC = window.DE_IC || {};
var doc = null, win = null;          /* iframe 内 */
var PD = window.document;            /* 父层 */
var bar = null, pal = null, saveDlg = null;
var arrN = 1;
var insertMenu=null;
var palMode = 'fg';   /* 色板作用：fg=边框/文字色，bg=底色 */

/* ==================== 样式 ==================== */
var UI_CSS = "\nhtml[data-de-mode=\"edit\"] #viewport{bottom:86px!important}\nhtml[data-de-mode=\"edit\"] body{padding-bottom:86px!important}\nhtml[data-de-mode=\"edit\"] *{animation-play-state:paused!important}\n.de-bar{position:fixed;left:50%;bottom:14px;transform:translateX(-50%);z-index:2147482500;display:flex;align-items:center;gap:2px;padding:7px 8px;background:#fffffff5;border:1px solid #d4deeb;border-radius:13px;box-shadow:0 6px 22px #183b6420;user-select:none;cursor:grab;max-width:calc(100% - 24px);font-family:-apple-system,\"PingFang SC\",sans-serif;color:#263e5f;box-sizing:border-box;line-height:1.4}\n.de-bar.dragging-bar{cursor:grabbing}.de-drag-hint{white-space:nowrap;flex-shrink:0;font-size:11px;line-height:1;color:#96a9c2;padding:0 3px;cursor:grab}.de-selection-hint{font-size:11px;color:#6d819b;min-width:0;max-width:65px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;padding:0 5px}.de-bbtn{min-width:30px;width:30px;flex-shrink:0;height:36px;display:flex;align-items:center;justify-content:center;gap:5px;background:transparent;border:0;border-radius:8px;color:#314b70;cursor:pointer;position:relative;padding:0 5px;font:13px/1.4 -apple-system,\"PingFang SC\",sans-serif;white-space:nowrap;box-sizing:border-box}.de-bbtn:hover{background:#eaf2fe}.de-bbtn:focus-visible{outline:3px solid #6c9de8;outline-offset:2px}.de-bbtn.disabled,.de-bbtn:disabled{opacity:.34;cursor:default}.de-bbtn svg{width:17px;height:17px;display:block;flex-shrink:0}.de-btxt{font-size:15px;font-weight:650}.de-btnlabel{display:none;font-size:13px;font-weight:500}.de-bsep{width:1px;height:23px;background:#d9e3ef;margin:0 3px;flex:0 0 auto}.de-bbtn[aria-expanded=\"true\"]{background:#e5efff;color:#1c4fa0}.de-tools-group{position:relative}.de-toolmenu{display:none;position:absolute;bottom:calc(100% + 12px);right:0;background:white;border:1px solid #d1dcea;border-radius:12px;box-shadow:0 12px 36px #1a365333;padding:10px;width:330px;box-sizing:border-box;grid-template-columns:1fr 1fr;gap:4px}.de-toolmenu.show{display:grid}.de-toolmenu>p{grid-column:1/-1;margin:0;padding:4px 7px;font-size:11px;color:#8292a7;line-height:1.4}.de-toolmenu .de-bbtn{width:auto;justify-content:flex-start;height:40px}.de-toolmenu .de-btnlabel{display:inline}.de-toolmenu label.de-bbtn{font:13px/1.4 -apple-system,\"PingFang SC\",sans-serif;cursor:pointer}.de-toolmenu .de-btnlabel{font-weight:400}.de-pal{position:fixed;z-index:2147482550;background:white;border:1px solid #cfdaea;border-radius:12px;padding:12px;display:none;grid-template-columns:repeat(6,1fr);gap:8px;box-shadow:0 12px 36px #1a365333;font:12px/1.4 -apple-system,\"PingFang SC\",sans-serif;color:#536b8b}.de-pal.show{display:grid}.de-sw{width:25px;height:25px;border-radius:6px;border:1px solid #c6d2e4;cursor:pointer}.de-sw:hover{outline:2px solid #5e90d5;outline-offset:2px}.de-pmode{grid-column:1/-1;display:flex;gap:7px;margin-bottom:4px}.de-pmode button{flex:1;appearance:none;border:1px solid #d6e0ef;background:white;color:#567293;font-size:12px;padding:7px;border-radius:7px;cursor:pointer;font-family:inherit}.de-pmode button.on{background:#eaf2ff;border-color:#97b8e8;color:#1c4fa0}.de-pick{grid-column:span 6;display:flex;align-items:center;gap:8px;font-size:12px;color:#69829f;margin-top:4px;padding-top:8px;border-top:1px solid #dce5f1}.de-pick input{flex:1;height:25px;border:0;background:transparent;cursor:pointer}.de-pal button:focus-visible,.de-sw:focus-visible{outline:3px solid #6c9de8;outline-offset:2px}\n@media(max-width:850px){.de-selection-hint{display:none}.de-bar{gap:2px;padding:7px}.de-bbtn{padding:0 6px}.de-bbtn svg{display:block}}@media(max-width:560px){.de-bar{flex-wrap:wrap;justify-content:center}.de-toolmenu{width:280px;right:-35px}}\n";

var PARENT_CSS = [
'#deSaveDlg{position:fixed;inset:0;background:rgba(6,10,18,.6);display:none;align-items:center;justify-content:center;z-index:10000;}',
'#deSaveDlg.show{display:flex;}',
'#deSaveDlg .sbox{background:#16233A;border:1px solid #2B3E5C;border-radius:12px;padding:22px 24px;width:460px;max-width:90vw;box-shadow:0 18px 50px rgba(0,0,0,.5);font-family:-apple-system,"PingFang SC",sans-serif;color:#DCE4F0;}',
'#deSaveDlg h3{font-size:16px;margin:0 0 8px;}',
'#deSaveDlg p{font-size:12.5px;color:#8FA2BE;line-height:1.65;margin:0 0 16px;}',
'#deSaveDlg .sbtns{display:flex;justify-content:flex-end;gap:10px;flex-wrap:wrap;}',
'#deSaveDlg .sbtns button{appearance:none;border:1px solid #2B3E5C;background:#1D2C46;color:#C9D6EA;font-size:13px;padding:8px 16px;border-radius:7px;cursor:pointer;font-family:inherit;}',
'#deSaveDlg .sbtns button:hover{background:#26395A;}',
'#deSaveDlg .sbtns button.primary{background:#1C4FA0;border-color:#2A62C0;color:#fff;}',
'#deSaveDlg .sbtns button.primary:hover{background:#2159B2;}'
].join('\n');

/* ==================== 工具 ==================== */
function ico(k) {
  return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round">' + (IC[k] || '') + '</svg>';
}
var labels = {'edit-text':'改文字','fs-down':'字号−','fs-up':'字号＋','bold':'加粗','color':'颜色','add-box':'方框','add-circle':'圆形','add-roundrect':'圆角方形','add-line':'线条 / 箭头','add-text':'文本','dash':'虚线 / 实线','arrow':'箭头开关','front':'置于顶层','back':'置于底层','parent':'选外层容器','del':'删除选中','undo':'撤销','save':'保存选项','close':'关闭文件','toggle-insert':'插入','toggle-more':'更多'};
function btn(cmd, content, tip) {
  return '<button class="de-bbtn" data-cmd="' + cmd + '" data-tip="' + tip + '" title="' + tip + '" aria-label="' + tip + '">' + content + '<span class="de-btnlabel">' + (labels[cmd] || tip) + '</span></button>';
}
var SEP = '<span class="de-bsep"></span>';
function clamp(v, a, b) { return v < a ? a : v > b ? b : v; }
function pdDirty() {
  if(DE.Shell && DE.Shell.edited)DE.Shell.edited();
  if (DE.Persist && DE.Persist.markDirty) { try { DE.Persist.markDirty(); } catch (e) {} }
}

/* 调色板：贴着工具条定位（bar 在下方→板上方；上方放不下→板下方） */
function placePal() {
  pal.classList.add('show');
  var br = bar.getBoundingClientRect();
  var pw = pal.offsetWidth, ph = pal.offsetHeight;
  var W = win.innerWidth, H = win.innerHeight;
  var l = Math.round(br.left + br.width / 2 - pw / 2);
  l = clamp(l, 8, Math.max(8, W - pw - 8));
  var t = br.top - ph - 10;
  if (t < 8) t = br.bottom + 10;
  if (t + ph > H - 8) t = Math.max(8, H - ph - 8);
  pal.style.transform = 'none';
  pal.style.bottom = 'auto';
  pal.style.left = l + 'px';
  pal.style.top = t + 'px';
}

/* 工具条位置：跨载入保持（存父层，iframe 重建不丢） */
function saveBarPos() {
  try {
    var r = bar.getBoundingClientRect();
    window.parent.__deBarPos = { l: r.left, t: r.top, W: win.innerWidth, H: win.innerHeight };
  } catch (e) {}
}
function restoreBarPos() {
  try {
    var p = window.parent.__deBarPos;
    if (!p) return;
    var kx = win.innerWidth / p.W, ky = win.innerHeight / p.H;
    var l = clamp(p.l * kx, 0, win.innerWidth - bar.offsetWidth);
    var t = clamp(p.t * ky, 0, win.innerHeight - bar.offsetHeight);
    bar.style.transform = 'none';
    bar.style.bottom = 'auto';
    bar.style.left = l + 'px';
    bar.style.top = t + 'px';
  } catch (e) {}
}
function isSvgEl(el) { return el && el.namespaceURI === 'http://www.w3.org/2000/svg'; }
function isBoxEl(el) { return !!(el.classList && el.classList.contains('de-box')); }
function isLineEl(el) { return !!(el.classList && el.classList.contains('de-line')); }
function isTextEl(el) { return !!(el.classList && el.classList.contains('de-text')); }
function isShapeEl(el) { return isBoxEl(el) || isLineEl(el); }
function deletable(el) {
  if (!el || !el.parentNode) return false;
  if (el.classList.contains('slide')) return false;
  if (el === doc.body || el === doc.documentElement || ['stage','slide','deck'].indexOf(el.id)>=0) return false;
  return true;
}

/* ==================== 构建 ==================== */
function attach(d, w) {
  doc = d; win = w;
  var st = d.createElement('style');
  st.id = 'de-ui-style';
  st.textContent = UI_CSS;
  d.head.appendChild(st);
  buildBar();
  d.addEventListener('pointerdown', onGlobalDown, true);
  d.addEventListener('keydown',onUiKey,true);
  console.log('[deck-editor] ui attached');
}
DE.ui = DE.ui || {};
DE.ui.attach = attach;
DE.ui.onSelChange = onSelChange;
DE.ui.openSave = openSave;
DE.ui.download = doDownload;
DE.ui.closeFile = closeFile;
DE.ui.setMode = function(mode){if(bar)bar.hidden = mode === 'preview'; if(pal)pal.classList.remove('show');closeMenus();if(win)win.dispatchEvent(new win.Event('resize'));};

function closeMenus(){if(insertMenu)insertMenu.classList.remove('show');if(bar)bar.querySelectorAll('[aria-expanded]').forEach(function(b){b.setAttribute('aria-expanded','false');});}
function toggleMenu(menu,cmd){var open=menu.classList.contains('show');closeMenus();if(pal)pal.classList.remove('show');if(!open){menu.classList.add('show');bar.querySelector('[data-cmd="'+cmd+'"]').setAttribute('aria-expanded','true');placeMenu(menu);}}
function placeMenu(menu){
  var br=bar.getBoundingClientRect(),above=br.top-20,below=win.innerHeight-br.bottom-20;
  menu.style.top='auto';menu.style.bottom='calc(100% + 12px)';menu.style.right='0';
  menu.style.maxHeight=Math.max(90,Math.max(above,below))+'px';menu.style.overflowY='auto';
  var r=menu.getBoundingClientRect();
  if(r.top<8 && below>above){menu.style.top='calc(100% + 12px)';menu.style.bottom='auto';}
  r=menu.getBoundingClientRect();
  if(r.right>win.innerWidth-8)menu.style.right=(r.right-win.innerWidth+8)+'px';
  else if(r.left<8)menu.style.right=(r.left-8)+'px';
}
function onGlobalDown(e){var t=e.target;if(!t.closest || !t.closest('.de-bar,.de-pal')){closeMenus();if(pal)pal.classList.remove('show');}}
function onUiKey(e){if(!e.target.closest || !e.target.closest('[data-de-ui]'))return;if(e.key==='Escape'){e.preventDefault();closeMenus();if(pal)pal.classList.remove('show');}if((e.metaKey||e.ctrlKey)&&e.key.toLowerCase()==='z'){e.preventDefault();DE.undo();}e.stopPropagation();}

function buildBar() {
  bar = doc.createElement('div');
  bar.setAttribute('data-de-ui', '1');
  bar.className = 'de-bar';
  bar.innerHTML =
    '<span class="de-drag-hint" title="按住空白处或这里拖动工具条" aria-hidden="true">拖动</span><span id="deSelectionHint" class="de-selection-hint">未选中</span>' + SEP +
    btn('edit-text',ico('text'),'修改选中的文字') +
    btn('fs-down','<span class="de-btxt">A-</span>','缩小字号') +
    btn('fs-up','<span class="de-btxt">A+</span>','放大字号') +
    btn('bold',ico('bold'),'加粗 / 取消') +
    btn('color',ico('color'),'修改颜色') + SEP +
    '<div class="de-tools-group">'+btn('toggle-insert',ico('insert'),'插入：文字、图片、形状、线条')+'<div id="deInsertMenu" class="de-toolmenu">'+
      '<p>添加到当前页面</p>'+btn('add-text',ico('text'),'插入文本')+
      '<label class="de-bbtn" data-tip="插入图片" id="deImgLab">'+ico('photo')+'<span class="de-btnlabel">图片</span><input type="file" accept="image/*" id="deImgIn" style="position:fixed;left:-300px;top:-300px;width:1px;height:1px;opacity:0;"></label>'+
      btn('add-box',ico('box'),'插入方框')+btn('add-circle',ico('circle'),'插入圆形')+btn('add-roundrect',ico('roundrect'),'插入圆角方形')+btn('add-line',ico('line'),'插入线条（箭头可开关）')+'</div></div>'+
    btn('front',ico('front'),'置于顶层（不被遮挡）')+btn('back',ico('back'),'置于底层')+btn('parent',ico('parent'),'选择上一级')+btn('del',ico('del'),'删除元素（可撤销）')+SEP+
    btn('dash',ico('dash'),'虚线 / 实线（方框、线条）')+btn('arrow',ico('arrow'),'箭头开关（线条）')+SEP+
    btn('save',ico('save'),'保存选项')+btn('close',ico('close'),'关闭文件')+
    btn('undo',ico('undo'),'撤销（⌘Z）');
  insertMenu=bar.querySelector('#deInsertMenu');
  [['toggle-insert','deInsertMenu']].forEach(function(pair){var b=bar.querySelector('[data-cmd="'+pair[0]+'"]');b.setAttribute('aria-expanded','false');b.setAttribute('aria-controls',pair[1]);});
  doc.body.appendChild(bar);
  restoreBarPos();
  bar.addEventListener('mousedown', function (e) {
    e.preventDefault();
    if (e.target.closest('.de-bbtn,.de-toolmenu')) return;   /* 按钮区不拖 */
    var r = bar.getBoundingClientRect();
    var l0 = r.left, t0 = r.top, sx = e.clientX, sy = e.clientY;
    var W = win.innerWidth, H = win.innerHeight, bw = r.width, bh = r.height;
    bar.style.transform = 'none';
    bar.style.bottom = 'auto';
    bar.style.left = l0 + 'px';
    bar.style.top = t0 + 'px';
    bar.classList.add('dragging-bar');
    if (pal) pal.classList.remove('show');
    function mv(ev) {
      bar.style.left = Math.min(Math.max(0, l0 + ev.clientX - sx), W - bw) + 'px';
      bar.style.top = Math.min(Math.max(0, t0 + ev.clientY - sy), H - bh) + 'px';
    }
    function up() {
      doc.removeEventListener('mousemove', mv);
      doc.removeEventListener('mouseup', up);
      bar.classList.remove('dragging-bar');
      saveBarPos();
    }
    doc.addEventListener('mousemove', mv);
    doc.addEventListener('mouseup', up);
  });
  bar.addEventListener('click', function (e) {
    var b = e.target.closest('[data-cmd]');
    if (!b || b.disabled) return;
    var cmd=b.getAttribute('data-cmd');
    if(cmd==='toggle-insert'){toggleMenu(insertMenu,cmd);return;}
    closeMenus();onCmd(cmd);
  });
  var imgIn = doc.getElementById('deImgIn');
  if (imgIn) imgIn.addEventListener('change', function () {
    insertImgFile(imgIn.files && imgIn.files[0]);
    imgIn.value = '';closeMenus();
  });

  pal = doc.createElement('div');
  pal.setAttribute('data-de-ui', '1');
  pal.className = 'de-pal';
  var cols = ['#C0392B', '#E0A63A', '#1E8E5A', '#164B9E', '#4A7FD0', '#7C3AED', '#0E7490', '#B45309', '#475569', '#16233A', '#8593A5', '#FFFFFF'];
  pal.innerHTML = '<div class="de-pmode"><button type="button" data-pmode="fg" class="on">边框</button><button type="button" data-pmode="bg">底色</button></div>' + cols.map(function (c) {
    return '<div class="de-sw" data-c="' + c + '" style="background:' + c + '"></div>';
  }).join('') + '<div class="de-pick">自定义<input type="color" id="dePick"></div>';
  doc.body.appendChild(pal);
  pal.addEventListener('mousedown', function (e) { e.preventDefault(); });
  pal.addEventListener('click', function (e) {
    var pm = e.target.closest('[data-pmode]');
    if (pm) {
      palMode = pm.getAttribute('data-pmode');
      var pb = pal.querySelectorAll('[data-pmode]');
      for (var i = 0; i < pb.length; i++) pb[i].classList.remove('on');
      pm.classList.add('on');
      return;
    }
    var s = e.target.closest('.de-sw');
    if (s) applyColor(s.getAttribute('data-c'), palMode);
  });
  var pick = pal.querySelector('#dePick');
  if (pick) pick.addEventListener('input', function () { applyColor(this.value, palMode); });
}

/* ==================== 状态刷新 ==================== */
function setDis(cmd, dis) {
  if (!bar) return;
  var b = bar.querySelector('[data-cmd="' + cmd + '"]');
  if(b){b.classList.toggle('disabled',!!dis);b.disabled=!!dis;}
}
function onSelChange() {
  if (!bar) return;
  var s = DE.sel;
  var hasShape = false, hasLine = false, canDel = false;
  for (var i = 0; i < s.length; i++) {
    if (isShapeEl(s[i])) hasShape = true;
    if (isLineEl(s[i])) hasLine = true;
    if (deletable(s[i])) canDel = true;
  }
  setDis('dash', !hasShape);
  setDis('arrow', !hasLine);
  setDis('del', !canDel);
  setDis('parent', s.length !== 1);
  var none = !s.length;
  setDis('edit-text',s.length!==1 || !DE.canEditText(s[0]));
  var hint=bar.querySelector('#deSelectionHint');var one=s[0],kind=one?(DE.canEditText(one)?'文字':one.tagName==='IMG'?'图片':isLineEl(one)?'线条':isShapeEl(one)?'图形':one.tagName==='TABLE'?'表格':'容器'):'';
  if(hint){hint.textContent=none?'未选中':s.length>1?'已选 '+s.length+' 项':kind;hint.title=hint.textContent;}
  if(pal){var fg=pal.querySelector('[data-pmode="fg"]'),bg=pal.querySelector('[data-pmode="bg"]');var text=s.length&&s.every(function(n){return DE.canEditText(n)||isTextEl(n)||(isSvgEl(n)&&n.tagName==='text');});if(fg)fg.textContent=text?'文字颜色':'边框颜色';if(bg)bg.textContent=text?'文字底色':'填充底色';}

  setDis('fs-up', none); setDis('fs-down', none);
  setDis('bold', none); setDis('color', none);
}

/* ==================== 命令 ==================== */
function onCmd(cmd) {
  if(cmd === 'edit-text'){var target = DE.sel[0];if(target && DE.canEditText(target)){DE.startEdit(target);}else{DE.toast('先选中一段文字，再点编辑文字，或直接双击。');}return;}
  if (cmd === 'save') { openSave(); return; }
  if (cmd === 'close') { closeFile(); return; }
  if (cmd === 'undo') { DE.undo(); return; }
  if (cmd === 'add-box') { addAnno('box'); return; }
  if (cmd === 'add-circle') { addAnno('circle'); return; }
  if (cmd === 'add-roundrect') { addAnno('roundrect'); return; }
  if (cmd === 'add-line') { addAnno('line'); return; }
  if (cmd === 'add-text') { addAnno('text'); return; }
  if (cmd === 'front') { doLayer(true); return; }
  if (cmd === 'back') { doLayer(false); return; }
  if (cmd === 'parent') {
    if (DE.sel.length !== 1) return;
    var p = DE.parentOf(DE.sel[0]);
    if (p !== DE.sel[0]) DE.select(p);
    return;
  }
  if (cmd === 'del') { doDelete(); return; }

  var s = DE.sel;
  if (!s.length) { DE.toast('先选中一个元素'); return; }
  if (cmd === 'fs-up') { doFont(2); return; }
  if (cmd === 'fs-down') { doFont(-2); return; }
  if (cmd === 'bold') { doBold(); return; }
  if (cmd === 'color') {
    if (pal.classList.contains('show')) pal.classList.remove('show');
    else placePal();
    return;
  }
  if (cmd === 'dash') { doDash(); return; }
  if (cmd === 'arrow') { doArrow(); return; }
}

function doFont(delta) {
  var s = DE.sel;
  DE.snap();
  s.forEach(function (el) {
    if (isSvgEl(el)) {
      if (el.tagName !== 'text') return;
      var cur = parseFloat(win.getComputedStyle(el).fontSize) || 16;
      el.style.fontSize = '';
      el.setAttribute('font-size', clamp(Math.round(cur + delta), 6, 200));
    } else {
      var cur2 = parseFloat(win.getComputedStyle(el).fontSize) || 16;
      el.style.fontSize = clamp(Math.round(cur2 + delta), 6, 200) + 'px';
    }
  });
  pdDirty();
  DE.refreshSel();
}

function doBold() {
  var s = DE.sel;
  DE.snap();
  s.forEach(function (el) {
    if (isSvgEl(el)) {
      if (el.tagName !== 'text') return;
      var w = el.getAttribute('font-weight');
      el.setAttribute('font-weight', (w === '700' || w === 'bold') ? '400' : '700');
    } else {
      var cw = win.getComputedStyle(el).fontWeight;
      var bold = cw === 'bold' || cw === '700' || parseInt(cw, 10) >= 600;
      el.style.fontWeight = bold ? '400' : '700';
    }
  });
  pdDirty();
  DE.refreshSel();
}

function applyColor(c, mode) {
  var s = DE.sel;
  if (!s.length) { DE.toast('先选中元素再选颜色'); return; }
  DE.snap();
  var isBg = (mode === 'bg');
  s.forEach(function (el) {
    if (el.classList && el.classList.contains('slide')) return;
    if (isSvgEl(el)) {
      if (isLineEl(el)) {
        if (isBg) return;   /* 线条没有底色 */
        var v = el.querySelector('.vis');
        if (v) { v.setAttribute('stroke', c); }
        var mk = el.querySelector('marker path');
        if (mk) mk.setAttribute('fill', c);
        return;
      }
      if (el.tagName === 'text') { el.setAttribute('fill', c); return; }
      /* SVG 形状：底色=fill；边框=stroke（无 stroke 时回退改 fill，保证可见） */
      var stk = el.getAttribute('stroke');
      if (isBg) { el.setAttribute('fill', c); return; }
      if (stk && stk !== 'none') { el.setAttribute('stroke', c); return; }
      el.setAttribute('fill', c);
      return;
    }
    /* ---- HTML 元素 ---- */
    if (isBg) {
      el.style.backgroundColor = c;
      if (el.tagName === 'TABLE') {
        var cells = el.querySelectorAll('td,th');
        for (var i = 0; i < cells.length; i++) cells[i].style.backgroundColor = c;
      }
      return;
    }
    if (isBoxEl(el)) {
      var bw = parseFloat(win.getComputedStyle(el).borderTopWidth) || 0;
      if (!bw) el.style.border = '2.5px solid ' + c;
      else el.style.borderColor = c;
      return;
    }
    if (el.tagName === 'TABLE') {
      var tbw = parseFloat(win.getComputedStyle(el).borderTopWidth) || 0;
      if (!tbw) el.style.border = '1.5px solid ' + c;
      else el.style.borderColor = c;
      var tds = el.querySelectorAll('td,th');
      for (var j = 0; j < tds.length; j++) {
        var cbw = parseFloat(win.getComputedStyle(tds[j]).borderTopWidth) || 0;
        if (cbw) tds[j].style.borderColor = c;
      }
      return;
    }
    var hasText = DE.canEditText(el);
    if (hasText || isTextEl(el)) { el.style.color = c; return; }
    /* 容器元素 → 边框色 */
    var cbw2 = parseFloat(win.getComputedStyle(el).borderTopWidth) || 0;
    if (!cbw2) el.style.border = '2px solid ' + c;
    else el.style.borderColor = c;
  });
  pdDirty();
  DE.refreshSel();
}

function doDash() {
  var s = DE.sel, done = false;
  s.forEach(function (el) {
    if (isBoxEl(el)) {
      if (!done) { DE.snap(); done = true; }
      el.style.borderStyle = (el.style.borderStyle === 'dashed') ? 'solid' : 'dashed';
      if (!el.style.borderColor) el.style.borderColor = '#C0392B';
    } else if (isLineEl(el)) {
      if (!done) { DE.snap(); done = true; }
      var v = el.querySelector('.vis');
      if (!v) return;
      var cur = v.getAttribute('stroke-dasharray');
      v.setAttribute('stroke-dasharray', cur ? '' : '10 7');
    }
  });
  if (!done) { DE.toast('虚线 / 实线仅对方框和线条有效'); return; }
  pdDirty();
  DE.refreshSel();
}

function doArrow() {
  var s = DE.sel, done = false;
  s.forEach(function (el) {
    if (isLineEl(el)) {
      if (!done) { DE.snap(); done = true; }
      var v = el.querySelector('.vis');
      var mk = el.querySelector('marker');
      if (!v || !mk) return;
      if (v.getAttribute('marker-end')) v.removeAttribute('marker-end');
      else v.setAttribute('marker-end', 'url(#' + mk.id + ')');
    }
  });
  if (!done) { DE.toast('箭头开关仅对线条有效'); return; }
  pdDirty();
  DE.refreshSel();
}

function doDelete() {
  var s = DE.sel.slice();
  var any = false, blocked = false;
  DE.snap();
  s.forEach(function (el) {
    if (!deletable(el)) { blocked = true; return; }
    el.parentNode.removeChild(el);
    any = true;
  });
  DE.sel.length = 0;
  pdDirty();
  DE.refreshSel();
  if (any) DE.toast('已删除（⌘Z 可撤销）');
  else if (blocked) DE.toast('页面框架不能删除');
}

/* ==================== 标注创建 ==================== */
/* 插入宿主：deck 页 -> 普通页面兜底 body（兼容数据看板等非 deck 文件） */
function findHost() {
  return doc.querySelector('#slide') || doc.querySelector('.slide.active') || doc.querySelector('.slide') || doc.body;
}
/* 插入点：当前视口中央换算到宿主坐标（宿主为 body 时即文档坐标） */
function insertXY(host, w, h) {
  var K = (host.offsetWidth && host.getBoundingClientRect().width / host.offsetWidth) || DE.getK();
  var vx = win.scrollX + win.innerWidth / 2;
  var vy = win.scrollY + win.innerHeight / 2;
  var hx = 0, hy = 0;
  if (host !== doc.body && host !== doc.documentElement) {
    var hr = host.getBoundingClientRect();
    hx = hr.left + win.scrollX;
    hy = hr.top + win.scrollY;
  }
  return {
    x: Math.round((vx - hx) / K - w / 2),
    y: Math.round((vy - hy) / K - h / 2)
  };
}
/* ==================== 层级调整 ==================== */
function doLayer(up) {
  var s = DE.sel;
  if (!s.length) { DE.toast('先选中一个元素'); return; }
  DE.snap();
  s.forEach(function (el) {
    if (el.classList && (el.classList.contains('slide') || el.id === 'deck')) return;
    var p = el.parentNode;
    if (!p || p.nodeType !== 1) return;
    if (isSvgEl(el) && p.namespaceURI === 'http://www.w3.org/2000/svg') {
      /* SVG 内部：层级=DOM 顺序 */
      if (up) p.appendChild(el);
      else p.insertBefore(el, p.firstChild);
      return;
    }
    if (win.getComputedStyle(el).position === 'static') el.style.position = 'relative';
    var maxZ = 0, minZ = 0, kids = p.children;
    for (var i = 0; i < kids.length; i++) {
      if (kids[i] === el) continue;
      var z = win.getComputedStyle(kids[i]).zIndex;
      if (z && z !== 'auto') {
        var zz = parseInt(z, 10) || 0;
        if (zz > maxZ) maxZ = zz;
        if (zz < minZ) minZ = zz;
      }
    }
    el.style.zIndex = String(up ? maxZ + 5 : minZ - 5);
  });
  pdDirty();
  DE.refreshSel();
  DE.toast(up ? '已置于顶层' : '已置于底层');
}

/* ==================== 插入图片 ==================== */
function insertImgFile(f) {
  if (!f) return;
  if (!/^image\//.test(f.type || '')) { DE.toast('请选择图片文件'); return; }
  var rd = new FileReader();
  rd.onload = function () {
    var host = findHost();
    var img = doc.createElement('img');
    img.className = 'de-anno de-img';
    img.setAttribute('data-de-anno', 'img');
    img.draggable = false;
    var done = false;
    img.onload = function () {
      if (done) return;
      done = true;
      var nw = img.naturalWidth || 300, nh = img.naturalHeight || 200;
      var maxW = 420;
      var w = nw > maxW ? maxW : nw;
      var h = Math.max(20, Math.round(nh * (w / nw)));
      var tp = insertXY(host, w, h);
      img.style.cssText = 'position:absolute;left:' + tp.x + 'px;top:' + tp.y + 'px;width:' + w + 'px;height:' + h + 'px;max-width:none;z-index:30;box-sizing:border-box;';
      if (DE.Persist && DE.Persist.beforeEdit) { try { DE.Persist.beforeEdit(); } catch (e) {} }
      host.appendChild(img);
      pdDirty();
      DE.select(img);
      DE.toast('已插入图片：拖动移位 · 拖手柄缩放 · 可调层级');
    };
    img.src = rd.result;
    if (img.complete && img.naturalWidth) img.onload();
  };
  rd.readAsDataURL(f);
}

function addAnno(type) {
  var host = findHost();
  DE.snap();
  var dims = { box: [360, 180], circle: [120, 120], roundrect: [220, 130], text: [260, 54], line: [250, 0] }[type] || [200, 100];
  var tp = insertXY(host, dims[0], dims[1]);
  var el;
  if (type === 'box') {
    el = doc.createElement('div');
    el.className = 'de-anno de-box';
    el.setAttribute('data-de-anno', 'box');
    el.style.cssText = 'position:absolute;left:' + tp.x + 'px;top:' + tp.y + 'px;width:360px;height:180px;border:2.5px solid #C0392B;border-radius:3px;z-index:30;box-sizing:border-box;';
    host.appendChild(el);
  } else if (type === 'circle' || type === 'roundrect') {
    el = doc.createElement('div');
    el.className = 'de-anno de-box';
    el.setAttribute('data-de-anno', type);
    if (type === 'circle') {
      el.style.cssText = 'position:absolute;left:' + tp.x + 'px;top:' + tp.y + 'px;width:120px;height:120px;border:2.5px solid #C0392B;border-radius:50%;z-index:30;box-sizing:border-box;';
    } else {
      el.style.cssText = 'position:absolute;left:' + tp.x + 'px;top:' + tp.y + 'px;width:220px;height:130px;border:2.5px solid #C0392B;border-radius:16px;z-index:30;box-sizing:border-box;';
    }
    host.appendChild(el);
  } else if (type === 'text') {
    el = doc.createElement('div');
    el.className = 'de-anno de-text';
    el.setAttribute('data-de-anno', 'text');
    el.style.cssText = 'position:absolute;left:' + tp.x + 'px;top:' + tp.y + 'px;width:260px;height:54px;box-sizing:border-box;font-size:26px;color:#C0392B;font-weight:600;z-index:31;white-space:pre-wrap;overflow-wrap:break-word;';
    el.textContent = '双击输入文字';
    host.appendChild(el);
  } else {
    el = buildLine(host, tp);
  }
  pdDirty();
  DE.select(el);
  if (type === 'text') {
    try { DE.startEdit(el); } catch (e) {}
    DE.toast('已插入文本，直接输入文字');
  } else {
    DE.toast('已插入：拖动移位 · 角点缩放 · 工具条改色 / 虚实' + (type === 'line' ? ' / 箭头' : ''));
  }
}

function buildLine(host, tp) {
  tp = tp || { x: 600, y: 390 };
  var NS = 'http://www.w3.org/2000/svg';
  var svg = doc.createElementNS(NS, 'svg');
  svg.setAttribute('class', 'de-anno de-line');
  svg.setAttribute('data-de-anno', 'line');
  svg.setAttribute('style', 'position:absolute;left:' + tp.x + 'px;top:' + tp.y + 'px;width:1px;height:1px;overflow:visible;z-index:32;');
  var mid = 'deArr' + (arrN++);
  var html = '<defs><marker id="' + mid + '" markerWidth="9" markerHeight="9" refX="7.5" refY="3" orient="auto" markerUnits="strokeWidth">'
    + '<path d="M0,0 L7.5,3 L0,6 z" fill="#C0392B"></path></marker></defs>'
    + '<line class="hit" x1="0" y1="0" x2="250" y2="0" stroke="transparent" stroke-width="16" pointer-events="stroke"></line>'
    + '<line class="vis" x1="0" y1="0" x2="250" y2="0" stroke="#C0392B" stroke-width="2.5" marker-end="url(#' + mid + ')"></line>'
    + '<circle class="de-ep" data-ep="1" cx="0" cy="0" r="6" fill="#fff" stroke="#4E8AE8" stroke-width="2.5" pointer-events="all" style="cursor:grab"></circle>'
    + '<circle class="de-ep" data-ep="2" cx="250" cy="0" r="6" fill="#fff" stroke="#4E8AE8" stroke-width="2.5" pointer-events="all" style="cursor:grab"></circle>';
  svg.innerHTML = html;
  host.appendChild(svg);
  return svg;
}

/* ==================== 关闭 / 保存 ==================== */
function closeFile() {
  if (DE.hasEdits() && !window.confirm('有未保存的修改，确定关闭吗？')) return;
  window.location.reload();
}

function buildClean() {
  if (DE.endEdit) DE.endEdit();
  if (DE.clearHover) DE.clearHover();
  /* 克隆文档树（不动原文档），清掉编辑器痕迹 */
  var nd = PD.implementation.createHTMLDocument('');
  nd.replaceChild(nd.importNode(doc.documentElement, true), nd.documentElement);
  var i, el;
  var rm = nd.querySelectorAll('[data-de-ui]');
  for (i = rm.length - 1; i >= 0; i--) rm[i].parentNode.removeChild(rm[i]);
  ['de-style', 'de-ui-style'].forEach(function (id) {
    var e = nd.getElementById(id);
    if (e) e.parentNode.removeChild(e);
  });
  var hov = nd.querySelectorAll('.de-hover');
  for (i = 0; i < hov.length; i++) hov[i].classList.remove('de-hover');
  var ce = nd.querySelectorAll('[contenteditable]');
  for (i = 0; i < ce.length; i++) ce[i].removeAttribute('contenteditable');
  nd.documentElement.removeAttribute('data-de-mode');
  var da = nd.querySelectorAll('[data-de-anno]');
  for (i = 0; i < da.length; i++) da[i].removeAttribute('data-de-anno');
  /* 清掉上一轮内嵌的保持层，再按当前会话状态重新内嵌 */
  var dp = nd.querySelectorAll('[data-de-persist]');
  for (i = dp.length - 1; i >= 0; i--) dp[i].parentNode.removeChild(dp[i]);
  try { if (DE.Persist && DE.Persist.embed) DE.Persist.embed(nd); } catch (e) { console.warn('[deck-editor] persist embed failed', e); }
  return '<!DOCTYPE html>\n' + nd.documentElement.outerHTML;
}
DE.buildClean = buildClean;

function buildSaveDlg() {
  if (saveDlg) return;
  var st = PD.createElement('style');
  st.textContent = PARENT_CSS;
  PD.head.appendChild(st);
  saveDlg = PD.createElement('div');
  saveDlg.id = 'deSaveDlg';
  saveDlg.innerHTML = '<div class="sbox">'
    + '<h3>保存选项</h3>'
    + '<p id="deSaveHint"></p>'
    + '<div class="sbtns">'
    + '<button class="primary" id="deDl">下载HTML文件</button>'
    + '<button id="deCkptBtn">暂存到浏览器</button>'
    + '<button id="deSaveOrig" style="display:none">保存回原文件</button>'
    + '<button id="deSaveCancel">取消</button>'
    + '</div></div>';
  PD.body.appendChild(saveDlg);
  saveDlg.querySelector('#deDl').addEventListener('click', function () {
    saveDlg.classList.remove('show');
    doDownload();
  });
  saveDlg.querySelector('#deSaveOrig').addEventListener('click', function () {
    saveDlg.classList.remove('show');
    saveToServer();
  });
  saveDlg.querySelector('#deCkptBtn').addEventListener('click', function () {
    saveDlg.classList.remove('show');
    if (DE.Ckpt && DE.Ckpt.save) DE.Ckpt.save(false);
  });
  saveDlg.querySelector('#deSaveCancel').addEventListener('click', function () {
    saveDlg.classList.remove('show');
  });
}

function openSave() {
  if (DE.endEdit) DE.endEdit();
  buildSaveDlg();
  var urlish = !!(DE.S.url && DE.S.url.indexOf('http') === 0);
  saveDlg.querySelector('#deSaveOrig').style.display = urlish ? '' : 'none';
  saveDlg.querySelector('#deSaveHint').textContent = urlish
    ? '「下载HTML文件」导出新文件；「保存回原文件」直接写回你打开的那个文件（需要本机 8777 服务）。'
    : '下载HTML文件：生成可带走、可独立打开的新文件。暂存到浏览器：保留工作进度，仍需下载才能交付。';
  if (DE.Ckpt && DE.Ckpt.decorateSaveDlg) DE.Ckpt.decorateSaveDlg(saveDlg);
  saveDlg.classList.add('show');
}

function doDownload() {
  if(!doc || !DE.S.text){DE.toast('先打开一份HTML文件');return;}
  var html = buildClean();
  try { if (DE.Ckpt && DE.Ckpt.save) DE.Ckpt.save(true, html); } catch (e) {}
  var blob = new Blob([html], { type: 'text/html;charset=utf-8' });
  var a = PD.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = (DE.S.name || 'deck.html').replace(/\.html?$/i,'').replace(/-已编辑$/,'') + '-已编辑.html';
  PD.body.appendChild(a);
  a.click();
  setTimeout(function () { URL.revokeObjectURL(a.href); a.remove(); }, 4000);
  if(DE.Shell && DE.Shell.status)DE.Shell.status('已发起下载 · 查看下载文件夹');
  DE.toast('已发起下载：新文件名带“已编辑”，原文件保留。',3500);
}

function saveToServer() {
  DE.toast('正在保存…');
  var html = buildClean();
  try { if (DE.Ckpt && DE.Ckpt.save) DE.Ckpt.save(true, html); } catch (e) {}
  fetch('http://127.0.0.1:8777/__save', {
    method: 'POST',
    headers: { 'Content-Type': 'text/plain' },
    body: JSON.stringify({ url: DE.S.url, html: html })
  }).then(function (r) {
    return r.json().catch(function () { return { ok: r.ok }; });
  }).then(function (j) {
    if (j && (j.ok || j.success)) DE.toast('已保存回原文件 ✓');
    else DE.toast('保存失败：' + ((j && (j.error || j.msg)) || '服务返回异常'), 4200);
  }).catch(function (e) {
    DE.toast('保存失败：' + e.message + '（本机服务 8777 是否运行？）', 4500);
  });
}

})();
