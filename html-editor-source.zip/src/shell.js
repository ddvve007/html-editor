/* Parent controls: compact, directly visible file tools. */
(function(){
'use strict';
var DE=window.DE,PD=document;
function status(text){var n=PD.getElementById('fileState');if(n)n.textContent=text;}
PD.querySelectorAll('[data-icon]').forEach(function(b){var svg=PD.createElementNS('http://www.w3.org/2000/svg','svg');svg.setAttribute('viewBox','0 0 24 24');svg.setAttribute('fill','none');svg.setAttribute('stroke','currentColor');svg.setAttribute('stroke-width','1.9');svg.setAttribute('stroke-linecap','round');svg.setAttribute('stroke-linejoin','round');svg.setAttribute('aria-hidden','true');svg.innerHTML=(window.DE_IC||{})[b.getAttribute('data-icon')]||'';b.prepend(svg);});
DE.Shell={status:status,loaded:function(){PD.getElementById('workGuide').hidden=false;['btnDraft','btnSaveOptions','btnCloseFile'].forEach(function(id){PD.getElementById(id).disabled=false;});status('本机编辑 · 原文件保留');},edited:function(){status('修改后请下载HTML');},setMode:function(mode){var preview=mode==='preview';PD.getElementById('guideMode').textContent=preview?'预览':'编辑';PD.getElementById('guideText').textContent=preview?'原页面互动可用 · 切回编辑继续改':'单击选中 · 双击改字 · 工具条可拖动';}};
PD.getElementById('btnSaveOptions').addEventListener('click',function(){if(DE.ui && DE.ui.openSave)DE.ui.openSave();});
PD.getElementById('btnDraft').addEventListener('click',function(){if(DE.endEdit)DE.endEdit();if(DE.Ckpt && DE.Ckpt.save(false))status('已暂存浏览器 · 交付请下载HTML');});
PD.getElementById('btnCloseFile').addEventListener('click',function(){if(DE.ui && DE.ui.closeFile)DE.ui.closeFile();});
})();
