/* ============================================================
 * HTML 编辑器 — 暂存进度（浏览器内检查点）
 * 改到一半点「暂存进度」：把当前进度存进浏览器（localStorage）；
 * 下次打开同一文件时可「恢复继续编辑」；最后「下载新文件」导出最终版。
 * 「下载新文件」「保存回原文件」也会自动暂存一份（静默）。
 * ============================================================ */
(function () {
'use strict';
var DE = window.DE = window.DE || {};
var PD = window.document;
var KEY = 'de_ckpt_v1';
var LIMIT = 2000000;              /* 字符上限（localStorage 一般约 5MB/源；保守起见 200 万字符） */
var dlg = null, pending = null;

function lsGet() { try { return window.localStorage.getItem(KEY); } catch (e) { return null; } }
function lsSet(s) { try { window.localStorage.setItem(KEY, s); return true; } catch (e) { return false; } }
function readAll() { try { var t = lsGet(); return t ? JSON.parse(t) : null; } catch (e) { return null; } }
function writeAll(o) { return lsSet(JSON.stringify(o)); }

function find(name, url) {
  var all = readAll(); if (!all || !all.items) return null;
  for (var k in all.items) {
    var it = all.items[k]; if (!it) continue;
    if (url && it.url && it.url === url) return { key: k, item: it };
    if (name && it.name === name) return { key: k, item: it };
  }
  return null;
}
function put(item) {
  var all = readAll() || { v: 1, items: {} };
  if (!all.items) all.items = {};
  var delKeys = [];
  for (var k in all.items) {
    var it = all.items[k];
    if (it && ((item.url && it.url && it.url === item.url) || (it.name && it.name === item.name))) delKeys.push(k);
  }
  for (var i = 0; i < delKeys.length; i++) delete all.items[delKeys[i]];
  var key = 'k' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
  all.items[key] = item;
  var ks = Object.keys(all.items);
  ks.sort();
  while (ks.length > 3) { delete all.items[ks.shift()]; }
  return writeAll(all) ? key : null;
}
function del(key) {
  var all = readAll(); if (!all || !all.items || !all.items[key]) return;
  delete all.items[key];
  writeAll(all);
}
function fmt(ts) {
  var d = new Date(ts), now = new Date();
  function p(n) { return (n < 10 ? '0' : '') + n; }
  var hm = p(d.getHours()) + ':' + p(d.getMinutes());
  if (d.toDateString() === now.toDateString()) return '今天 ' + hm;
  var y = new Date(now.getTime() - 86400000);
  if (d.toDateString() === y.toDateString()) return '昨天 ' + hm;
  return (d.getMonth() + 1) + '月' + d.getDate() + '日 ' + hm;
}

/* ==================== 对外接口 ==================== */
DE.Ckpt = {};

DE.Ckpt.current = function () { return find(DE.S.name, DE.S.url); };

DE.Ckpt.save = function (silent, prebuilt) {
  var html = prebuilt || (DE.buildClean ? DE.buildClean() : '');
  if (!html) return false;
  if (!html || html.length > LIMIT) {
    if (!silent) DE.toast('暂存失败：文件较大，超出浏览器存储上限，请改用「下载新文件」导出', 4600);
    return false;
  }
  var item = { name: DE.S.name || 'deck.html', url: DE.S.url || '', ts: Date.now(), len: html.length, html: html };
  var key = put(item);
  if (!key) { if (!silent) DE.toast('暂存失败：浏览器存储空间不足，请用「下载新文件」导出', 4600); return false; }
  if (!silent) DE.toast('进度已暂存到浏览器；交付前仍需下载HTML文件', 3800);
  if (!silent && dlg) dlg.classList.remove('show');
  return true;
};

DE.Ckpt.remove = function () { var f = DE.Ckpt.current(); if (f) { del(f.key); DE.toast('已删除暂存'); } };

/* 打开文件前的分叉：有暂存 → 弹恢复选择；无 → 直接载入 */
DE.Ckpt.intercept = function (name, url, text, okMsg) {
  var f = find(name, url);
  if (!f) { DE.load(text, name, url); if (okMsg) DE.toast(okMsg); return; }
  pending = { f: f, name: name, url: url, text: text, okMsg: okMsg };
  buildDlg();
  dlg.querySelector('#deCkptWho').textContent = '《' + (name || '未命名') + '》在 ' + fmt(f.item.ts) + ' 暂存过一版（可能包含你的修改）。';
  dlg.classList.add('show');
};

/* 打开「保存」对话框时，显示/更新暂存状态行 */
DE.Ckpt.decorateSaveDlg = function (sd) {
  var f = DE.Ckpt.current();
  var line = sd.querySelector('#deCkptLine');
  if (!line) {
    line = PD.createElement('p');
    line.id = 'deCkptLine';
    line.style.cssText = 'font-size:12px;color:#8FA2BE;margin:0 0 14px;line-height:1.6;';
    var btns = sd.querySelector('.sbtns');
    btns.parentNode.insertBefore(line, btns);
  }
  if (f) {
    line.innerHTML = '已暂存：' + fmt(f.item.ts) + '（点此<a href="#" id="deCkptDelLink" style="color:#8FB7F0;text-decoration:none;">删除暂存</a>）';
    var a = line.querySelector('#deCkptDelLink');
    if (a) a.addEventListener('click', function (ev) {
      ev.preventDefault();
      del(f.key);
      DE.toast('已删除暂存');
      DE.Ckpt.decorateSaveDlg(sd);
    });
  } else {
    line.textContent = '浏览器暂存只保留工作进度。需要交付或换电脑，请下载HTML文件。';
  }
};

/* ==================== 恢复对话框 ==================== */
var CSS = [
'#deCkptDlg{position:fixed;inset:0;background:rgba(6,10,18,.6);display:none;align-items:center;justify-content:center;z-index:10010;}',
'#deCkptDlg.show{display:flex;}',
'#deCkptDlg .sbox{background:#16233A;border:1px solid #2B3E5C;border-radius:12px;padding:22px 24px;width:500px;max-width:90vw;box-shadow:0 18px 50px rgba(0,0,0,.5);font-family:-apple-system,"PingFang SC",sans-serif;color:#DCE4F0;}',
'#deCkptDlg h3{font-size:16px;margin:0 0 10px;}',
'#deCkptDlg p{font-size:12.5px;color:#8FA2BE;line-height:1.7;margin:0 0 8px;}',
'#deCkptDlg .sbtns{display:flex;justify-content:flex-end;gap:10px;flex-wrap:wrap;margin-top:16px;}',
'#deCkptDlg .sbtns button{appearance:none;border:1px solid #2B3E5C;background:#1D2C46;color:#C9D6EA;font-size:13px;padding:8px 16px;border-radius:7px;cursor:pointer;font-family:inherit;}',
'#deCkptDlg .sbtns button:hover{background:#26395A;}',
'#deCkptDlg .sbtns button.primary{background:#1C4FA0;border-color:#2A62C0;color:#fff;}',
'#deCkptDlg .sbtns button.primary:hover{background:#2159B2;}'
].join('\n');

function buildDlg() {
  if (dlg) return;
  var st = PD.createElement('style');
  st.textContent = CSS;
  PD.head.appendChild(st);
  dlg = PD.createElement('div');
  dlg.id = 'deCkptDlg';
  dlg.innerHTML = '<div class="sbox">'
    + '<h3>发现暂存进度</h3>'
    + '<p id="deCkptWho"></p>'
    + '<p>「恢复继续编辑」：带着已暂存的修改接着改（推荐）。<br>「从原文件打开」：忽略这次暂存，暂存仍保留。</p>'
    + '<div class="sbtns">'
    + '<button class="primary" id="deCkptRestore">恢复继续编辑</button>'
    + '<button id="deCkptOrig">从原文件打开</button>'
    + '<button id="deCkptDel">删除暂存</button>'
    + '</div></div>';
  PD.body.appendChild(dlg);

  dlg.querySelector('#deCkptRestore').addEventListener('click', function () {
    var p = pending; if (!p) return;
    dlg.classList.remove('show');
    DE.load(p.f.item.html, p.f.item.name || p.name, p.f.item.url || '');
    DE.toast('已恢复暂存进度（' + fmt(p.f.item.ts) + '）', 3600);
  });
  dlg.querySelector('#deCkptOrig').addEventListener('click', function () {
    var p = pending; if (!p) return;
    dlg.classList.remove('show');
    DE.load(p.text, p.name, p.url);
    if (p.okMsg) DE.toast(p.okMsg);
  });
  dlg.querySelector('#deCkptDel').addEventListener('click', function () {
    var p = pending; if (!p) return;
    dlg.classList.remove('show');
    del(p.f.key);
    DE.load(p.text, p.name, p.url);
    DE.toast('已删除暂存，已打开原文件', 3200);
  });
}

})();
