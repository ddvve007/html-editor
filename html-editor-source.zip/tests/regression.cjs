const {JSDOM,VirtualConsole}=require('jsdom');
const fs=require('fs'),path=require('path'),assert=require('node:assert/strict');
const root=path.resolve(process.argv[2]||path.join(__dirname,'..'));
const fixture=process.argv[3];
if(!fixture)throw new Error('Pass a compatible dynamic fixture: node tests/regression.cjs <editor-dir> <fixture.html> [zh|en]');
const source=fs.readFileSync(fixture,'utf8');
const en=process.argv[4]==='en';
const L=(zh,english)=>en?english:zh;
const quiet=new VirtualConsole();
function tick(){return new Promise(r=>setTimeout(r,0));}
async function host(html=source){
 const shell=fs.readFileSync(path.join(root,en?'html-editor-en.html':'html-editor.html'),'utf8');
 const parent=new JSDOM(shell,{runScripts:'outside-only',url:'https://editor.test/',pretendToBeVisual:true,virtualConsole:quiet});
 const w=parent.window;
 for(const script of w.document.querySelectorAll('script'))w.eval(script.textContent);
 const child=new JSDOM(html,{runScripts:'dangerously',url:'https://editor.test/deck',pretendToBeVisual:true,virtualConsole:quiet});
 const f=w.document.getElementById('canvas');
 Object.defineProperty(f,'contentDocument',{configurable:true,get:()=>child.window.document});
 Object.defineProperty(f,'contentWindow',{configurable:true,get:()=>child.window});
 w.DE.load(html,'sample.html','');f.onload();await tick();
 return {w,d:child.window.document,child,close(){child.window.close();w.close();}};
}
function click(h,selector){const e=h.d.querySelector(selector);assert(e,selector);e.click();}
async function edit(h,sel,text){const el=h.d.querySelector(sel);h.w.DE.startEdit(el);el.textContent=text;h.w.DE.endEdit();await tick();}
const tests=[];function test(n,f){tests.push([n,f]);}
test('撤销相邻元素的多选删除会恢复原顺序',async()=>{
 const h=await host('<html><body><main><p>A</p><p>B</p><p>C</p></main></body></html>');
 try {
  const nodes=Array.from(h.d.querySelectorAll('p'));
  h.w.DE.sel.push(...nodes.slice(0,2));
  h.w.DE.refreshSel();
  click(h,'[data-cmd="del"]');
  assert.deepEqual(Array.from(h.d.querySelectorAll('p')),nodes.slice(2));
  h.w.DE.undo();
  assert.deepEqual(Array.from(h.d.querySelectorAll('p')),nodes);
 } finally {h.close();}
});
test('撤销恢复 SVG 原有变换',async()=>{
 const h=await host('<html><body><svg><rect transform="translate(4 2)"/></svg></body></html>');
 try {
  const rect=h.d.querySelector('rect');
  h.w.DE.snap();
  rect.setAttribute('transform','translate(5 2)');
  h.w.DE.undo();
  assert.equal(rect.getAttribute('transform'),'translate(4 2)');
 } finally {h.close();}
});
test('重新打开成品后，空撤销保留原有标注且新箭头 ID 唯一',async()=>{
 const original=await host('<html><body><main><p>Content</p><div class="de-anno de-box">Saved</div></main><svg><marker id="deArr1"/></svg></body></html>');
 const exported=original.w.DE.buildClean();
 original.close();
 const h=await host(exported);
 try {
  h.w.DE.undo();
  assert.equal(h.d.querySelector('.de-box').textContent,'Saved');
  click(h,'[data-cmd="add-line"]');
  const markers=Array.from(h.d.querySelectorAll('marker'),el=>el.id);
  assert.equal(markers.length,2);
  assert.equal(new Set(markers).size,2);
 } finally {h.close();}
});
test('编辑模式隔离各类课件快捷键并保留输入，预览模式放行',async()=>{
 const h=await host('<html><body><p>Editable text</p><input value="Input text"></body></html>');
 try {
  let pageKeys=0;
  const types=['keydown','keypress','keyup'];
  for(const type of types)h.d.addEventListener(type,()=>pageKeys++,true);
  const text=h.d.querySelector('p'),input=h.d.querySelector('input');
  h.w.DE.startEdit(text);
  for(const target of [text,input]){
   target.focus();
   for(const type of types)for(const key of ['f','N','r',' ','Backspace','Delete','ArrowLeft','Home','Enter','Process']){
    const event=new h.child.window.KeyboardEvent(type,{key,bubbles:true,cancelable:true});
    assert.equal(target.dispatchEvent(event),true);
   }
  }
  assert.equal(pageKeys,0);
  assert(text.isConnected);
  input.blur();
  for(const type of types)h.d.body.dispatchEvent(new h.child.window.KeyboardEvent(type,{key:'f',bubbles:true,cancelable:true}));
  assert.equal(pageKeys,0);
  h.w.DE.setMode('preview');
  for(const type of types)h.d.body.dispatchEvent(new h.child.window.KeyboardEvent(type,{key:'f',bubbles:true,cancelable:true}));
  assert.equal(pageKeys,types.length);
 } finally {h.close();}
});
test('删除键删除选中元素并可撤销，空选时阻止页面后退',async()=>{
 const h=await host('<html><body><p>Removable text</p><p>Keep this text</p></body></html>');
 try {
  const text=h.d.querySelector('p');
  for(const key of ['Backspace','Delete']){
   h.w.DE.select(text);
   const event=new h.child.window.KeyboardEvent('keydown',{key,bubbles:true,cancelable:true});
   assert.equal(h.d.body.dispatchEvent(event),false);
   assert.equal(text.isConnected,false);
   h.w.DE.undo();
   assert.equal(h.d.querySelector('p'),text);
  }
  const event=new h.child.window.KeyboardEvent('keydown',{key:'Backspace',bubbles:true,cancelable:true});
  assert.equal(h.d.body.dispatchEvent(event),false);
  assert(text.isConnected);
 } finally {h.close();}
});
test('编辑器旧版固定高度随行数变化，作者高度保留，撤销恢复原高度',async()=>{
 const h=await host('<html><body><h1 style="width:300px;height:80px;box-sizing:border-box;flex-shrink:0;min-height:0;overflow-wrap:break-word">First<br>Second</h1><p style="height:95px">Fixed</p></body></html>');
 try {
  const heading=h.d.querySelector('h1'), fixed=h.d.querySelector('p');
  const {window}=h.child;
  const input=(el,text)=>{el.textContent=text;el.dispatchEvent(new window.Event('input',{bubbles:true}));};
  for(const el of [heading,fixed]){
   Object.defineProperty(el,'offsetHeight',{get:()=>parseFloat(el.style.height)||(el.querySelector('br')?80:40)});
   el.getBoundingClientRect=()=>({left:5,top:5,right:305,bottom:5+el.offsetHeight,width:300,height:el.offsetHeight});
  }
  h.w.DE.startEdit(heading);
  input(heading,'First');
  assert.equal(heading.style.height,'auto');
  assert.equal(h.d.querySelector('.de-selbox').style.height,'40px');
  h.w.DE.endEdit();
  h.w.DE.undo();
  assert.equal(heading.style.height,'80px');
  assert.equal(heading.innerHTML,'First<br>Second');
  h.w.DE.startEdit(fixed);
  input(fixed,'Changed');
  assert.equal(fixed.style.height,'95px');
 } finally {h.close();}
});
test('双击能编辑包含换行的段落',async()=>{const h=await host();click(h,'[aria-label="跳转第4页"]');await tick();const el=h.d.querySelector('.prompt-bad .quote');el.dispatchEvent(new h.child.window.MouseEvent('dblclick',{bubbles:true}));assert.equal(el.getAttribute('contenteditable'),'true');assert.equal(h.w.DE.sel[0],el);assert.equal(h.d.querySelector('#deSelectionHint').textContent,L('文字','Text'));h.close();});
test('修改的标题在同页互动重画后保留',async()=>{const h=await host();click(h,'[aria-label="跳转第4页"]');await tick();await edit(h,'#slide h1','测试标题：清晰描述任务');if(h.w.DE.setMode)h.w.DE.setMode('preview');click(h,'.prompt-part');await tick();assert.equal(h.d.querySelector('#slide h1').textContent,'测试标题：清晰描述任务');h.close();});
test('编辑模式阻止课件按钮执行，并有预览模式',async()=>{const h=await host();click(h,'[aria-label="跳转第4页"]');await tick();assert.equal(h.w.DE.mode,'edit');click(h,'.prompt-part');await tick();assert.equal(h.d.querySelector('.prompt-part').getAttribute('aria-pressed'),'false');h.w.DE.setMode('preview');click(h,'.prompt-part');await tick();assert.equal(h.d.querySelector('.prompt-part').getAttribute('aria-pressed'),'true');h.close();});
test('导出重开后修改保留，互动仍能执行',async()=>{const h=await host();click(h,'[aria-label="跳转第4页"]');await tick();await edit(h,'#slide h1','导出后的新标题');const html=h.w.DE.buildClean();assert(!html.includes('id="de-boxlayer"'));const opened=new JSDOM(html,{runScripts:'dangerously',url:'https://editor.test/export',virtualConsole:quiet});await tick();opened.window.document.querySelector('[aria-label="跳转第4页"]').click();await tick();assert.equal(opened.window.document.querySelector('#slide h1').textContent,'导出后的新标题');opened.window.document.querySelector('.prompt-part').click();await tick();assert.equal(opened.window.document.querySelector('#slide h1').textContent,'导出后的新标题');assert.equal(opened.window.document.querySelector('.prompt-part').getAttribute('aria-pressed'),'true');opened.window.close();h.close();});
test('修改只属于当前页，不串到其他页面',async()=>{const h=await host();click(h,'[aria-label="跳转第4页"]');await tick();await edit(h,'#slide h1','只修改第四页');click(h,'[aria-label="跳转第5页"]');await tick();assert(h.d.querySelector('#slide h1').textContent.includes('Skill'));click(h,'[aria-label="跳转第4页"]');await tick();assert.equal(h.d.querySelector('#slide h1').textContent,'只修改第四页');h.close();});
test('修改某个概念解释，不替换其他概念',async()=>{const h=await host();h.w.DE.setMode('preview');click(h,'[aria-label="跳转第2页"]');click(h,'.catalog-item[data-value="1"]');await tick();h.w.DE.setMode('edit');await edit(h,'.concept-definition','LLM的新解释');h.w.DE.setMode('preview');click(h,'.catalog-item[data-value="0"]');await tick();assert(h.d.querySelector('.concept-definition').textContent.includes('AI助手'));click(h,'.catalog-item[data-value="1"]');await tick();assert.equal(h.d.querySelector('.concept-definition').textContent,'LLM的新解释');h.close();});
test('包含换行的文字改动可以撤销',async()=>{const h=await host();click(h,'[aria-label="跳转第4页"]');await tick();const original=h.d.querySelector('.quote').innerHTML;await edit(h,'.quote','新的说明');h.w.DE.undo();await tick();assert.equal(h.d.querySelector('.quote').innerHTML,original);h.close();});
test('字号修改在互动后保留',async()=>{const h=await host();click(h,'[aria-label="跳转第4页"]');await tick();h.w.DE.select(h.d.querySelector('#slide h1'));click(h,'[data-cmd="fs-up"]');const font=h.d.querySelector('#slide h1').style.fontSize;assert(font);h.w.DE.setMode('preview');click(h,'.prompt-part');await tick();assert.equal(h.d.querySelector('#slide h1').style.fontSize,font);h.close();});
test('插入的标注随当前页保存，不污染其他页',async()=>{const h=await host();click(h,'[aria-label="跳转第4页"]');await tick();click(h,'[data-cmd="add-text"]');h.w.DE.endEdit();await tick();assert.equal(h.d.querySelectorAll('#slide .de-anno').length,1);click(h,'[aria-label="跳转第5页"]');await tick();assert.equal(h.d.querySelectorAll('#slide .de-anno').length,0);click(h,'[aria-label="跳转第4页"]');await tick();assert.equal(h.d.querySelectorAll('#slide .de-anno').length,1);h.close();});
test('导出文件可重新导入并再次修改',async()=>{const h=await host();click(h,'[aria-label="跳转第4页"]');await tick();await edit(h,'#slide h1','第一轮编辑');const second=await host(h.w.DE.buildClean());click(second,'[aria-label="跳转第4页"]');await tick();await edit(second,'#slide h1','第二轮编辑');second.w.DE.setMode('preview');click(second,'.prompt-part');await tick();assert.equal(second.d.querySelector('#slide h1').textContent,'第二轮编辑');second.close();h.close();});
test('静态HTML正文可编辑，脚本与图片保留',async()=>{const h=await host('<!doctype html><html><head><style>p{color:red}</style></head><body><h1>静态报告</h1><p>原始内容</p><img src="data:image/png;base64,abc"><script>window.example=7;</script></body></html>');await edit(h,'p','修改后的正文');const html=h.w.DE.buildClean();assert(html.includes('修改后的正文'));assert(html.includes('data:image/png;base64,abc'));assert(html.includes('window.example=7'));assert(!html.includes('id="de-style"'));h.close();});
test('正在编辑时保存会提交最后输入的文字',async()=>{const h=await host();click(h,'[aria-label="跳转第4页"]');await tick();const el=h.d.querySelector('#slide h1');h.w.DE.startEdit(el);el.textContent='未失焦也能保存';const html=h.w.DE.buildClean();const opened=new JSDOM(html,{runScripts:'dangerously',url:'https://editor.test/export',virtualConsole:quiet});await tick();opened.window.document.querySelector('[aria-label="跳转第4页"]').click();await tick();assert.equal(opened.window.document.querySelector('#slide h1').textContent,'未失焦也能保存');opened.window.close();h.close();});
test('HTML源码面板可编辑并应用完整文件',async()=>{const h=await host();h.w.DE.openSource();const a=h.w.document.getElementById('sourceArea');assert(a.value.includes('Vibe Marketing'));a.value='<!doctype html><html><body><h1>从源码修改</h1></body></html>';h.w.document.getElementById('sourceApply').click();assert(h.w.DE.S.text.includes('从源码修改'));assert(h.w.document.querySelector('.de-source').hidden);h.close();});
test('浏览器暂存包含导出的动态修改',async()=>{const h=await host();click(h,'[aria-label="跳转第4页"]');await tick();await edit(h,'#slide h1','暂存标题');assert.equal(h.w.DE.Ckpt.save(true),true);const stored=h.w.DE.Ckpt.current();assert(stored.item.html.includes('暂存标题'));assert(stored.item.html.includes('data-de-persist'));h.close();});
test('顶部文件工具直接显示并有悬浮提示',async()=>{const h=await host(),p=h.w.document;assert(!p.getElementById('moreMenu'));['btnSource','btnReload','btnDraft','btnOpenUrl','btnSaveOptions','btnHelp','btnCloseFile'].forEach(id=>{const e=p.getElementById(id);assert(e.closest('.top-actions'));assert(e.title);assert(e.querySelector('svg'));});h.close();});
test('层级等命令直接显示，插入菜单包含全部添加选项',async()=>{const h=await host();const required=['edit-text','fs-down','fs-up','bold','color','add-text','add-box','add-circle','add-roundrect','add-line','front','back','parent','del','dash','arrow','save','close','undo'];required.forEach(c=>{const e=h.d.querySelector('[data-cmd="'+c+'"]');assert(e,c);assert(e.title,c);if(!c.startsWith('add-'))assert(!e.closest('.de-toolmenu'),c);});assert(!h.d.querySelector('#deExtraMenu'));assert(h.d.querySelector('#deImgIn'));assert.equal(h.d.querySelector('[data-cmd="fs-down"] .de-btxt').textContent,'A-');assert.equal(h.d.querySelector('[data-cmd="fs-up"] .de-btxt').textContent,'A+');assert(h.d.querySelector('[data-cmd="toggle-insert"]').title.includes(L('形状','shapes')));click(h,'[data-cmd="toggle-insert"]');assert(h.d.querySelector('#deInsertMenu').classList.contains('show'));h.w.DE.setMode('preview');assert(!h.d.querySelector('#deInsertMenu').classList.contains('show'));assert(h.d.querySelector('.de-bar').hidden);h.w.DE.setMode('edit');assert(!h.d.querySelector('.de-bar').hidden);h.close();});
test('包含换行的文字能改颜色，面板标签区分文字和形状',async()=>{const h=await host();click(h,'[aria-label="跳转第4页"]');await tick();const quote=h.d.querySelector('.quote');h.w.DE.select(quote);assert.equal(h.d.querySelector('[data-pmode="fg"]').textContent,L('文字颜色','Text color'));click(h,'[data-cmd="color"]');click(h,'[data-c="#164B9E"]');assert.equal(quote.style.color,'rgb(22, 75, 158)');click(h,'[data-cmd="add-box"]');assert.equal(h.d.querySelector('[data-pmode="fg"]').textContent,L('边框颜色','Border color'));h.close();});
test('下载按钮直接导出新文件，清理编辑UI并保留动效',async()=>{const h=await host();let download='';h.w.URL.createObjectURL=()=> 'blob:editor-test';h.w.URL.revokeObjectURL=()=>{};h.w.HTMLAnchorElement.prototype.click=function(){download=this.download;};click(h,'[aria-label="跳转第4页"]');await tick();const heading=h.d.querySelector('#slide h1');h.w.DE.startEdit(heading);heading.textContent='下载实测标题';h.w.document.getElementById('btnSaveTop').click();assert.equal(download,L('sample-已编辑.html','sample-edited.html'));assert(!h.w.document.getElementById('deSaveDlg'));assert(h.w.DE.buildClean().includes('下载实测标题'));assert(!h.w.DE.buildClean().includes('animation-play-state:paused!important'));assert(!h.w.DE.buildClean().includes('data-de-mode="edit"'));assert(h.w.document.getElementById('fileState').textContent.includes(L('已发起下载','Download started')));h.close();});
test('工具条仍可拖动并记住位置，按钮点击不会启动拖动',async()=>{const h=await host(),bar=h.d.querySelector('.de-bar');Object.defineProperty(bar,'getBoundingClientRect',{value:()=>({left:100,top:250,width:600,height:56,right:700,bottom:306})});const mouse=(target,type,x,y)=>target.dispatchEvent(new h.child.window.MouseEvent(type,{bubbles:true,clientX:x,clientY:y}));mouse(bar.querySelector('.de-drag-hint'),'mousedown',110,260);mouse(h.d,'mousemove',150,140);mouse(h.d,'mouseup',150,140);assert.equal(bar.style.left,'140px');assert.equal(bar.style.top,'130px');assert(!bar.classList.contains('dragging-bar'));assert(h.w.__deBarPos);assert.equal(h.w.__deBarPos.l,100);mouse(bar.querySelector('[data-cmd="toggle-insert"]'),'mousedown',150,140);assert(!bar.classList.contains('dragging-bar'));h.close();});
function fakeRect(el,w=200,height=60,scale=1){Object.defineProperty(el,'offsetWidth',{configurable:true,get:()=>parseFloat(el.style.width)||w});Object.defineProperty(el,'offsetHeight',{configurable:true,get:()=>parseFloat(el.style.height)||height});el.getBoundingClientRect=()=>{const width=el.offsetWidth*scale,h=el.offsetHeight*scale;return {left:100,top:100,width,height:h,right:100+width,bottom:100+h};};}
function resize(h,el,dir,dx,dy,shift=false){h.w.DE.endEdit();h.w.DE.select(el);const handle=h.d.querySelector('[data-h="'+dir+'"]'),e=(type,x,y)=>{const event=new h.child.window.MouseEvent(type,{bubbles:true,button:0,clientX:x,clientY:y,shiftKey:shift});Object.defineProperty(event,'isPrimary',{value:true});return event;};handle.dispatchEvent(e('pointerdown',200,130));h.d.dispatchEvent(e('pointermove',200+dx,130+dy));h.d.dispatchEvent(e('pointerup',200+dx,130+dy));}
test('原有文本框能单独拉宽拉高，字号不变且可撤销',async()=>{const h=await host('<html><body><p style="font-size:26px">原有文本框</p></body></html>'),el=h.d.querySelector('p');fakeRect(el);resize(h,el,'e',100,0);assert.equal(el.style.width,'300px');assert.equal(el.style.height,'');assert.equal(el.style.fontSize,'26px');assert(!el.style.transform.includes('scale('));resize(h,el,'s',0,50);assert.equal(el.style.width,'300px');assert.equal(el.style.height,'110px');h.w.DE.undo();assert.equal(el.style.height,'');h.close();});
test('插入文本框可自由拉长并随课件导出保持',async()=>{const h=await host();click(h,'[aria-label="跳转第4页"]');await tick();click(h,'[data-cmd="add-text"]');h.w.DE.endEdit();const el=h.d.querySelector('.de-text');assert.equal(el.style.width,'260px');assert.equal(el.style.height,'');assert.equal(h.d.querySelector('[data-cmd="add-text"] .de-btnlabel').textContent,L('文本','Text'));fakeRect(el);el.style.width='200px';el.style.height='60px';resize(h,el,'e',80,0);assert.equal(el.style.width,'280px');assert.equal(el.style.height,'60px');assert.equal(el.style.fontSize,'26px');const opened=await host(h.w.DE.buildClean());click(opened,'[aria-label="跳转第4页"]');await tick();assert.equal(opened.d.querySelector('.de-text').style.width,'280px');assert.equal(opened.d.querySelector('.de-text').style.fontSize,'26px');opened.close();h.close();});
test('缩放画布下文本宽高与左上锚点正确，Shift角点仍等比',async()=>{const h=await host('<html><body><div id="text" style="position:absolute;left:30px;top:40px;width:200px;height:60px;font-size:26px">文本框</div></body></html>'),el=h.d.querySelector('#text');fakeRect(el,200,60,0.5);fakeRect(el.parentElement,800,600,0.5);resize(h,el,'w',-50,0);assert.equal(el.style.width,'300px');assert.equal(el.style.left,'-70px');resize(h,el,'n',0,-20);assert.equal(el.style.height,'100px');assert.equal(el.style.top,'0px');resize(h,el,'se',75,10,true);assert.equal(el.style.width,'450px');assert.equal(el.style.height,'150px');assert.equal(el.style.fontSize,'26px');h.close();});
test('原课件文本拉伸在互动重画及导出重开后保持',async()=>{const h=await host();click(h,'[aria-label="跳转第4页"]');await tick();const el=h.d.querySelector('#slide h1');fakeRect(el);resize(h,el,'e',70,0);assert.equal(el.style.width,'270px');h.w.DE.setMode('preview');click(h,'.prompt-part');await tick();assert.equal(h.d.querySelector('#slide h1').style.width,'270px');const opened=await host(h.w.DE.buildClean());click(opened,'[aria-label="跳转第4页"]');await tick();assert.equal(opened.d.querySelector('#slide h1').style.width,'270px');opened.close();h.close();});
(async()=>{let failures=0;for(const [n,f]of tests){try{await f();console.log('PASS',n);}catch(e){failures++;console.log('FAIL',n,'—',e.message);}}console.log(`${tests.length-failures}/${tests.length} passed`);process.exitCode=failures?1:0;})();
